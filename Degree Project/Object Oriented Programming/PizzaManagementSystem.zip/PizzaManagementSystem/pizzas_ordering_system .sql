-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 26, 2023 at 04:14 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pizzas_ordering_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `currLogin`
--

CREATE TABLE `currLogin` (
  `currLogin_id` int(11) NOT NULL,
  `currLogin_userId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `currLogin`
--

INSERT INTO `currLogin` (`currLogin_id`, `currLogin_userId`) VALUES
(1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `order_user` int(11) NOT NULL COMMENT 'refer user.user_id',
  `order_pizza` int(11) NOT NULL COMMENT 'refer pizza.pizza_id',
  `order_size_crust` int(11) NOT NULL COMMENT 'refer size_crust.sc_id',
  `order_topping` int(11) NOT NULL COMMENT 'refer topping.topping_id',
  `order_quantity` int(11) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1 COMMENT '1=pending, 2=complete'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `order_user`, `order_pizza`, `order_size_crust`, `order_topping`, `order_quantity`, `status`) VALUES
(109, 3, 9, 1, 10, 2, 2),
(108, 3, 9, 7, 10, 1, 2),
(107, 3, 8, 1, 6, 1, 2),
(106, 3, 1, 5, 1, 1, 2),
(103, 3, 1, 7, 6, 1, 2),
(102, 3, 1, 1, 2, 1, 2),
(99, 3, 6, 6, 1, 1, 2),
(104, 3, 5, 0, 0, 1, 2),
(100, 3, 4, 5, 4, 1, 2),
(95, 3, 5, 0, 6, 0, 2),
(94, 3, 4, 7, 4, 0, 2),
(93, 3, 4, 4, 4, 0, 2),
(92, 3, 6, 6, 6, 0, 2),
(91, 3, 3, 0, 0, 0, 2),
(90, 4, 4, 4, 4, 0, 2),
(89, 4, 4, 4, 6, 0, 2),
(88, 4, 6, 3, 3, 0, 2),
(87, 4, 2, 3, 3, 0, 2),
(86, 4, 4, 3, 3, 0, 2),
(85, 4, 4, 4, 4, 0, 2),
(84, 4, 8, 6, 1, 0, 2),
(83, 4, 8, 6, 6, 0, 2),
(82, 3, 3, 4, 3, 0, 2),
(81, 4, 4, 5, 4, 0, 2),
(80, 4, 0, 0, 0, 0, 2),
(79, 4, 4, 5, 4, 0, 2),
(78, 4, 6, 4, 4, 0, 2),
(77, 4, 2, 4, 4, 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` int(11) NOT NULL,
  `payment_orders` int(11) NOT NULL COMMENT 'refer orders.order_id',
  `payment_price` decimal(10,2) NOT NULL,
  `payment_paid` decimal(10,2) NOT NULL,
  `payment_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_id`, `payment_orders`, `payment_price`, `payment_paid`, `payment_date`) VALUES
(44, 4, '34.10', '40.00', '2023-01-26 05:34:12'),
(43, 3, '49.00', '50.00', '2023-01-26 05:33:44'),
(51, 3, '16.60', '20.00', '2023-01-26 05:47:19'),
(50, 3, '29.90', '30.00', '2023-01-26 05:47:01'),
(49, 4, '104.80', '105.00', '2023-01-26 05:45:35'),
(52, 3, '109.00', '200.00', '2023-01-26 10:20:51'),
(48, 4, '84.00', '100.00', '2023-01-26 05:44:12'),
(47, 4, '201.00', '300.00', '2023-01-26 05:43:24'),
(53, 3, '125.30', '150.00', '2023-01-26 10:32:41'),
(54, 3, '29.90', '30.00', '2023-01-26 10:36:46'),
(45, 4, '54.00', '60.00', '2023-01-26 05:35:54'),
(46, 4, '42.00', '50.00', '2023-01-26 05:40:07'),
(42, 4, '51.00', '60.00', '2023-01-26 05:33:17'),
(55, 3, '149.10', '200.00', '2023-01-26 10:40:30');

-- --------------------------------------------------------

--
-- Table structure for table `pizza`
--

CREATE TABLE `pizza` (
  `pizza_id` int(11) NOT NULL,
  `pizza_name` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pizza`
--

INSERT INTO `pizza` (`pizza_id`, `pizza_name`) VALUES
(0, 'BLAZING SEAFOOD'),
(1, 'CREAMY CHICKEN FIESTA'),
(2, 'CREAMY BEEF FIESTA'),
(3, 'TRIPLE CHICKEN'),
(4, 'CHICKEN PEPPERONI'),
(5, 'BEEF PEPPERONI'),
(6, 'DELUXE CHEESE'),
(7, 'VEGGIE LOVER'),
(8, 'ISLAND TUNA'),
(9, 'CHICKEN DELIGHT');

-- --------------------------------------------------------

--
-- Table structure for table `size_crust`
--

CREATE TABLE `size_crust` (
  `sc_id` int(11) NOT NULL,
  `sc_name` varchar(50) NOT NULL,
  `sc_price` decimal(10,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `size_crust`
--

INSERT INTO `size_crust` (`sc_id`, `sc_name`, `sc_price`) VALUES
(0, 'REGULAR PAN', '29.90'),
(1, 'REGULAR CHEEZY CRUST', '34.90'),
(2, 'REGULAR LIGHT CRUST', '30.90'),
(3, 'LARGE PAN', '41.50'),
(4, 'LARGE CHEEZY CRUST', '48.50'),
(5, 'LARGE LIGHT CRUST', '45.50'),
(6, 'PERSONAL PAN', '14.30'),
(7, 'PERSONAL CHEEZY CRUST', '17.30');

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `state_id` int(11) NOT NULL,
  `state_name` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`state_id`, `state_name`) VALUES
(1, 'JOHOR'),
(2, 'KEDAH'),
(3, 'KELANTAN'),
(4, 'MELAKA'),
(5, 'NEGERI SEMBILAN'),
(6, 'PAHANG'),
(7, 'PULAU PINANG'),
(8, 'PERAK'),
(9, 'PERLIS'),
(10, 'SABAH'),
(11, 'SARAWAK'),
(12, 'SELANGOR'),
(13, 'TERENGGANU'),
(14, 'WP KUALA LUMPUR'),
(15, 'WP LABUAN'),
(16, 'WP PUTRAJAYA');

-- --------------------------------------------------------

--
-- Table structure for table `topping`
--

CREATE TABLE `topping` (
  `topping_id` int(11) NOT NULL,
  `topping_name` varchar(50) NOT NULL,
  `topping_charge` decimal(10,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `topping`
--

INSERT INTO `topping` (`topping_id`, `topping_name`, `topping_charge`) VALUES
(2, 'MOZARELLA', '2.30'),
(3, 'ONION', '0.50'),
(4, 'BEEF MINCE', '5.50'),
(5, 'CHICKEN MINCE', '4.50'),
(6, 'OLIVE', '2.30'),
(7, 'CAPSICUM', '2.30'),
(8, 'MUSHROOM', '1.90'),
(9, 'PINEAPPLE', '2.60'),
(10, 'PRAWNS', '5.50'),
(1, 'KALE', '3.20'),
(0, 'NONE', '0.00');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_password` varchar(50) NOT NULL,
  `user_phone` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_email`, `user_password`, `user_phone`) VALUES
(4, 'Mira', 'a@gmail.com', '12345', '0197664526'),
(3, 'A', 'shiwwinzahra@gmail.com', '12', '0196334218');

-- --------------------------------------------------------

--
-- Table structure for table `user_address`
--

CREATE TABLE `user_address` (
  `ua_id` int(11) NOT NULL,
  `ua_user` int(11) NOT NULL COMMENT 'refer user.user_id',
  `ua_address` varchar(50) NOT NULL,
  `ua_city` varchar(50) NOT NULL,
  `ua_postcode` varchar(5) NOT NULL,
  `ua_state` int(11) NOT NULL COMMENT 'refer state.state_id'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_address`
--

INSERT INTO `user_address` (`ua_id`, `ua_user`, `ua_address`, `ua_city`, `ua_postcode`, `ua_state`) VALUES
(1, 2, '4, JALAN BBP 3, TAMAN BATU BERENDAM PUTRA', 'BATU BERENDAM', '75350', 4),
(2, 3, 'BTHO', 'Cheras', '43200', 12),
(3, 4, 'Chretas', 'chears', '31321', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `currLogin`
--
ALTER TABLE `currLogin`
  ADD PRIMARY KEY (`currLogin_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `pizza`
--
ALTER TABLE `pizza`
  ADD PRIMARY KEY (`pizza_id`);

--
-- Indexes for table `size_crust`
--
ALTER TABLE `size_crust`
  ADD PRIMARY KEY (`sc_id`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`state_id`);

--
-- Indexes for table `topping`
--
ALTER TABLE `topping`
  ADD PRIMARY KEY (`topping_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_address`
--
ALTER TABLE `user_address`
  ADD PRIMARY KEY (`ua_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `currLogin`
--
ALTER TABLE `currLogin`
  MODIFY `currLogin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `pizza`
--
ALTER TABLE `pizza`
  MODIFY `pizza_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `size_crust`
--
ALTER TABLE `size_crust`
  MODIFY `sc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
  MODIFY `state_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `topping`
--
ALTER TABLE `topping`
  MODIFY `topping_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user_address`
--
ALTER TABLE `user_address`
  MODIFY `ua_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
