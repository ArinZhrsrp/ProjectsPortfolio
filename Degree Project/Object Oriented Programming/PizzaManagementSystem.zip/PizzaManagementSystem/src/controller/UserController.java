package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.time.LocalDateTime;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

import database.DatabaseConnection;
import model.User;
import model.UserAddress;
import model.UserState;
import model.Orders;
import model.Payment;


public class UserController 
{
	public static int userId;
	
	public boolean logIn(User user) throws ClassNotFoundException, SQLException
	{
		boolean success= false;
		
		String sql =  "select * from user where user_name = '"+ user.getName() +"' and user_password='"+ user.getPassword() +"'";
		
		//1. Connection 
		Connection conn = DatabaseConnection.getConnection();
		
		//2. PreparedStatement
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		
		//3. View or insert/update
		ResultSet resultSet = preparedStatement.executeQuery();
		
		if(resultSet.next())
		{
			int id = resultSet.getInt("user_id");
			
			userId = id;
			success = true;
			
			String update =  "UPDATE currlogin set currLogin_userId = '"+ userId +"'";
			

			//2. PreparedStatement
			PreparedStatement preparedStatement2 = conn.prepareStatement(update);

			//3. Execute update
			int affectedRows = preparedStatement2.executeUpdate();

			if(affectedRows > 0) {
			    JOptionPane.showMessageDialog(null, "Login Successfull"); 
			} else {
			    JOptionPane.showMessageDialog(null, "Failed to login");
			}
		}
		
		//4. Must close the connection
		conn.close();
		
		JOptionPane.showMessageDialog(null, userId);
		user.setId(userId);
		
		return success;
	}
	
	public boolean findUser(User user) throws ClassNotFoundException, SQLException
	{
		boolean success= false;
		String sql = "select user_email from user where user_email = ?";
		
		//1. Connection 
		Connection conn = DatabaseConnection.getConnection();
		//2. PreparedStatement
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		preparedStatement.setString(1, user.getName());
		
		//3. View or insert/update
		ResultSet resultSet = preparedStatement.executeQuery();
		if(resultSet.next())
		{
			success = true;
		
			//System.out.println(success);
		}
		//4. Must close the connection
		conn.close();
				

		return success;
	}
	
	public int findState(User user, UserState userState) throws ClassNotFoundException, SQLException
	{
		int success = -1;
		String sql = "SELECT * FROM state";
		
		if(findUser(user) == true)
		{
			return success;
		}
		else
		{
			Connection conn = DatabaseConnection.getConnection();
			PreparedStatement preparedStatement = conn.prepareStatement(sql);
			preparedStatement.setString(1, userState.getState());
			
			success = preparedStatement.executeUpdate() + preparedStatement.executeUpdate();
			
			
			//4. Must close the connection
			conn.close();
		}
		return success;
	}
	
	public int insertUser(User user) throws ClassNotFoundException, SQLException
	{
		int success = -1;
		String sql1 = "insert into user ( user_name, user_email, user_password, user_phone) values(?,?,?,?)";
		
		if(findUser(user)==true)
		{
			return success;
		}
		else
		{
			
			//1. Connection 
			Connection conn = DatabaseConnection.getConnection();
			//2. PreparedStatement
			PreparedStatement preparedStatement1 = conn.prepareStatement(sql1);
			preparedStatement1.setString(1, user.getName());
			preparedStatement1.setString(2, user.getEmail());
			preparedStatement1.setString(3, user.getPassword());
			preparedStatement1.setString(4, user.getPhoneNo());
			
			
			//3. View or insert/update
			success = preparedStatement1.executeUpdate();
			
			
			//4. Must close the connection
			conn.close();
		}
		
		return success;
	}
	public void findEmail(User user) throws ClassNotFoundException, SQLException
	{
		boolean success= false;
		
		String sql =  "select * from user where user_email = '"+ user.getEmail() +"'";
		
		//1. Connection 
		Connection conn = DatabaseConnection.getConnection();
		
		//2. PreparedStatement
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		
		//3. View or insert/update
		ResultSet resultSet = preparedStatement.executeQuery();
		
		if(resultSet.next())
		{
			int id = resultSet.getInt("user_id");
			
			userId = id;
			success = true;
			
			
			String update =  "UPDATE user set user_password = '"+ user.getPassword() +"' where user_email = '"+ user.getEmail() +"'";
			

			//2. PreparedStatement
			PreparedStatement preparedStatement2 = conn.prepareStatement(update);

			//3. Execute update
			int affectedRows = preparedStatement2.executeUpdate();

			if(affectedRows > 0) {
			    JOptionPane.showMessageDialog(null, "Successfully changed your password"); 
			} else {
			    JOptionPane.showMessageDialog(null, "Failed to change your password");
			}
			
		}
		
		//4. Must close the connection
		conn.close();
		
	}
	public void showData() throws ClassNotFoundException, SQLException
	{
		JTable table = new JTable();
		int userId;
		String sql =  "SELECT * FROM currLogin WHERE currLogin_id = 1";
		
		//1. Connection 
		Connection conn = DatabaseConnection.getConnection();
		
		//2. PreparedStatement
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		
		//3. View or insert/update
		ResultSet resultSet = preparedStatement.executeQuery();
		
		if(resultSet.next())
		{
			int id = resultSet.getInt("currLogin_userId");
			userId = id;
			JOptionPane.showMessageDialog(null, userId); 
			
			DefaultTableModel model = new DefaultTableModel();
			model.addColumn("No");
			model.addColumn("Pizza");
			model.addColumn("Size & Crust");
			model.addColumn("Topping");
			model.addColumn("Quantity");
			
			try
			{
				String q_order = "SELECT * FROM orders WHERE status = 1 && order_user = '"+ userId +"'";
				Statement st = conn.createStatement();
				ResultSet rs = st.executeQuery(q_order);
				
				while(rs.next())
				{
					model.addRow(new Object []
							{
									rs.getInt("order_id"),
									rs.getString("order_pizza"),
									rs.getString("order_size_crust"),
									rs.getString("order_topping"),
									rs.getString("order_quantity")
							});
				}
				
				rs.close();
				st.close();
				conn.close();
				
				table.setModel(model);
				table.setAutoResizeMode(0);
				table.getColumnModel().getColumn(0).setPreferredWidth(60);
				table.getColumnModel().getColumn(1).setPreferredWidth(200);
				table.getColumnModel().getColumn(2).setPreferredWidth(80);
				table.getColumnModel().getColumn(3).setPreferredWidth(200);
				table.getColumnModel().getColumn(4).setPreferredWidth(80);
				
			}
			catch(Exception ex)
			{
				System.out.println("error : " + ex);
			}
			
			
		}
		
		//4. Must close the connection
		conn.close();
		
	}
	public String calc() throws ClassNotFoundException, SQLException
	{
		JTable table = new JTable();
		int userId;
		double finalPrice =0;
		String s = "";
		String sql =  "SELECT * FROM currLogin WHERE currLogin_id = 1";
		DecimalFormat df = new DecimalFormat("#.00");
		
		//1. Connection 
		Connection conn = DatabaseConnection.getConnection();
		
		//2. PreparedStatement
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		
		//3. View or insert/update
		ResultSet resultSet = preparedStatement.executeQuery();
		
		if(resultSet.next())
		{
			int id = resultSet.getInt("currLogin_userId");
			userId = id;

			try
			{
				String orders_query = "SELECT * FROM orders o "
						+ "INNER JOIN pizza p ON p.pizza_id = o.order_pizza "
						+ "INNER JOIN topping t ON t.topping_id = o.order_topping "
						+ "INNER JOIN size_crust sc ON sc.sc_id = o.order_size_crust "
						+ "WHERE o.status = 1 && o.order_user = " + userId;
				Statement st = conn.createStatement();
				ResultSet resOrders = st.executeQuery(orders_query);
				
				while(resOrders.next())
				{
					//for result orders
					int quantity = resOrders.getInt("order_quantity");
					double toppingCharge = resOrders.getDouble("topping_charge");
					double sizePrice = resOrders.getDouble("sc_price");
					
					finalPrice += sizePrice + toppingCharge;
					
				}
				s = String.valueOf(df.format(finalPrice));
				
				//System.out.println(finalPrice);
			}
			catch(Exception ex)
			{
				System.out.println("error : " + ex);
			}
			
			
		}
		
		//4. Must close the connection
		
		
		conn.close();
		return s;
	
	}
	
	
	public int insertOrder(User user,Orders order) throws ClassNotFoundException, SQLException
	{
		
		UserController uc = new UserController();
		boolean currentlogin = uc.logIn(user);

		int success = -1;
		int userId = 0;
		int pizzaId =0;
		int scid = 0;
		int toppingid = 0;
		
		//get pizza_id
				try
				{
					//1. Connection 
					Connection conn = DatabaseConnection.getConnection();
					
					//2 Statement
					Statement stmt = conn.createStatement();
					ResultSet res = stmt.executeQuery("SELECT * FROM pizza WHERE pizza_id = '" + order.getOrder_pizza() + "' ");
					
					//3. View or insert/update
					res.next();
					int id = res.getInt("pizza_id");
					pizzaId = id;
					
					
				}
				catch(Exception ae)
				{
					System.out.println(ae.getMessage());
				}
				
				//get size_id
				try
				{
					//1. Connection 
					Connection conn = DatabaseConnection.getConnection();
					
					//2 Statement
					Statement stmt = conn.createStatement();
					ResultSet res = stmt.executeQuery("SELECT * FROM size_crust WHERE sc_id = '" + order.getOrder_size() + "' ");
					
					//3. View or insert/update
					res.next();
					int id = res.getInt("sc_id");
					scid = id;
					
					
				}
				catch(Exception ae)
				{
					System.out.println(ae.getMessage());
				}
				
				//get topping_id
				try
				{
					//1. Connection 
					Connection conn = DatabaseConnection.getConnection();
					
					//2 Statement
					Statement stmt = conn.createStatement();
					ResultSet res = stmt.executeQuery("SELECT * FROM topping WHERE topping_id = '" + order.getOrder_topping() + "' ");
					
					//3. View or insert/update
					res.next();
					int id = res.getInt("topping_id");
					toppingid = id;
					
					
				}
				catch(Exception ae)
				{
					System.out.println(ae.getMessage());
				}
	
				//insert into order
				System.out.println("User id : " +user.getId());
				System.out.println("Pizza id : "+ pizzaId);
				System.out.println("Size Crust id : "+ scid);
				System.out.println("Topping id : "+ toppingid);
				System.out.println("Quantity : "+ order.getOrder_quantity());
				System.out.println("Status : " + order.getStatus());
				
				
				String sql2 = "insert into orders (order_user,order_pizza, order_size_crust, order_topping,order_quantity, status) values(?,?,?,?,?,?)";
			
					//1. Connection 
					Connection conn = DatabaseConnection.getConnection();
					//2. PreparedStatement
					PreparedStatement preparedStatement2 = conn.prepareStatement(sql2);
					preparedStatement2.setInt(1,user.getId());
					preparedStatement2.setInt(2,pizzaId);
					preparedStatement2.setInt(3,scid);
					preparedStatement2.setInt(4,toppingid);
					preparedStatement2.setInt(5, order.getOrder_quantity());
					preparedStatement2.setInt(6, order.getStatus());
					
					//3. View or insert/update
					success = preparedStatement2.executeUpdate();
					
					//4. Must close the connection
					conn.close();
					
					int id = user.getId();
					user.setId(id);
				return success;
	}
	
	public int insertUserAddress(User user,UserAddress userAddress) throws ClassNotFoundException, SQLException
	{
		int success = -1;
		int userId = 0;
		int stateId = 0;
		
		//query get Uuser_id
		try
		{
			//1. Connection 
			Connection conn = DatabaseConnection.getConnection();
			
			//2 Statement
			Statement stmt = conn.createStatement();
			ResultSet res = stmt.executeQuery("SELECT MAX(user_id) AS 'user_id' FROM user");
			
			//3. View or insert/update
			res.next();
			int id = res.getInt("user_id");
			userId = id;
			
			System.out.println(userId);
		}
		catch(Exception ae)
		{
			System.out.println(ae.getMessage());
		}
		
		//get state_id
		try
		{
			//1. Connection 
			Connection conn = DatabaseConnection.getConnection();
			
			//2 Statement
			Statement stmt = conn.createStatement();
			ResultSet res = stmt.executeQuery("SELECT * FROM state WHERE state_name = '" + userAddress.getState() + "' ");
			
			//3. View or insert/update
			res.next();
			int id = res.getInt("state_id");
			stateId = id;
			
			System.out.println(stateId);
		}
		catch(Exception ae)
		{
			System.out.println(ae.getMessage());
		}
		
		//insert into user_address
		String sql2 = "insert into user_address (ua_user, ua_address, ua_city, ua_postcode, ua_state) values (?,?,?,?,?)";
		
		if(findUser(user)==true)
		{
			
			return success;
		}
		else
		{
			
			//1. Connection 
			Connection conn = DatabaseConnection.getConnection();
			//2. PreparedStatement
			PreparedStatement preparedStatement2 = conn.prepareStatement(sql2);
			preparedStatement2.setInt(1, userId);
			preparedStatement2.setString(2, userAddress.getAddress());
			preparedStatement2.setString(3, userAddress.getCity());
			preparedStatement2.setString(4, userAddress.getPostcode());
			preparedStatement2.setInt(5, stateId);
			
			//3. View or insert/update
			success = preparedStatement2.executeUpdate();
			
			
			//4. Must close the connection
			conn.close();
		}
		
		return success;
	}
	
	public JTextArea receiptTextArea()
	{
		DatabaseConnection db_conn = new DatabaseConnection();
		Connection conn = db_conn.getConnection();
		JTextArea receiptTxt = null;
		
		//JOptionPane.showMessageDialog(null, userId);
		
		try
		{
			

			//orders query 
			String orders_query = "SELECT * FROM orders o "
					+ "INNER JOIN pizza p ON p.pizza_id = o.order_pizza "
					+ "INNER JOIN topping t ON t.topping_id = o.order_topping "
					+ "INNER JOIN size_crust sc ON sc.sc_id = o.order_size_crust "
					+ "WHERE o.status = 1 && o.order_user = " + userId;
			PreparedStatement stmtOrders = conn.prepareStatement(orders_query);
			ResultSet resOrders = stmtOrders.executeQuery();
			
			//users query
			String users_query = "SELECT * FROM user u "
					+ "INNER JOIN user_address ua ON ua.ua_user = u.user_id "
					+ "INNER JOIN state s ON s.state_id = ua.ua_state "
					+ "WHERE u.user_id = " + userId;
			PreparedStatement stmtUsers = conn.prepareStatement(users_query);
			ResultSet resUsers = stmtUsers.executeQuery();
			
			
			
			//query to get amount paid, balance and date
			String total_query = "SELECT * from payment INNER JOIN orders WHERE orders.status = 1 "
					+ "&& orders.order_user = "+ userId + " && orders.order_user = payment.payment_orders ORDER BY payment.payment_date DESC limit 1 ";
			PreparedStatement stmtTotal = conn.prepareStatement(total_query);
			ResultSet resTotal = stmtTotal.executeQuery();
			
			
			while(resUsers.next())
			{
				//for result user
				String userName = resUsers.getString("user_name");
				String userEmail = resUsers.getString("user_email");
				String userPhone = resUsers.getString("user_phone");
				String userAdd = resUsers.getString("ua_address");
				String userCity = resUsers.getString("ua_city");
				String userPostcode = resUsers.getString("ua_postcode");
				String userState = resUsers.getString("state_name");
				
				
				
				receiptTxt = new JTextArea(
						"\t       PIZZA ORDERING SYSTEM \n\n"
					  +	"\tNo. 1 Ground Floor, Jalan Bbp 1, Taman,\n"
					  + "\t       75350 Batu Berendam, Melaka"
					  +	"\n\t             Tel No: 011-3992 3149\n"
					  + "\n ====================================================\n"
					  + "   CUSTOMER "	
					  + "\n ====================================================\n"
					  + "  NAME            : " + userName 
					  + "\n  E-MAIL          : " + userEmail
					  + "\n  PHONE NO : " + userPhone
					  + "\n\n  ADDRESS   : \n " + userAdd + ",\n " + userCity + ", " + userPostcode + ",\n "+ userState + "."
					  + "\n\n ====================================================\n"
					  + "   ORDER LIST "	
					  + "\n====================================================\n"
						
					);
						
				//contentPane.add(textArea, BorderLayout.CENTER);
				//textArea.setEditable(false);	
				
			}
			
			while(resOrders.next())
			{
				//for result orders
				int quantity = resOrders.getInt("order_quantity");
				String pizzaName = resOrders.getString("pizza_name");
				String toppingName = resOrders.getString("topping_name");
				String sizeName = resOrders.getString("sc_name");
				double toppingCharge = resOrders.getDouble("topping_charge");
				double sizePrice = resOrders.getDouble("sc_price");
				
				receiptTxt.append(
						" " + quantity + "x " + pizzaName
					  + "\n - " + sizeName + "\t\tRM " + sizePrice
					  + "\n - " + toppingName + "\t\t\tRM " + toppingCharge + "\n\n"
						);	
				
			}
			
			while(resTotal.next())
			{
				DecimalFormat df = new DecimalFormat("#.00");
				//for total result
				double totalPrice = resTotal.getDouble("payment_price");
				double totalPaid = resTotal.getDouble("payment_paid");
				double totalBalance = totalPaid - totalPrice;
				String date = resTotal.getString("payment_date");
				
				receiptTxt.append(
						 " ====================================================\n"
					   + "  DATE : " + date
					   + "\n\n  TOTAL \t\t\tRM " + totalPrice
					   + "\n  CASH\t\t\tRM " + totalPaid
					   + "\n  BALANCE\t\t\tRM " + df.format(totalBalance)
					   + "\n\n                THANK YOU FOR ORDERING PIZZA WITH US!"
						);	
				
			}
			
			// Update the status column in the orders table
						String sql = "UPDATE orders SET status = ? WHERE order_user = ?";
					    PreparedStatement orderStatement = conn.prepareStatement(sql);
					    orderStatement.setInt(1, 2);
					    orderStatement.setInt(2, userId);
					    int rowsUpdated = orderStatement.executeUpdate();
					    orderStatement.close();
			
			
			receiptTxt.setBounds(20, 107, 411, 343);
			receiptTxt.setEditable(false);
			
			
			resOrders.close();
			stmtOrders.close();
			
			resUsers.close();
			stmtUsers.close();
			
			resTotal.close();
			stmtTotal.close();
			
			conn.close();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		return receiptTxt;
	}
}

	
	


