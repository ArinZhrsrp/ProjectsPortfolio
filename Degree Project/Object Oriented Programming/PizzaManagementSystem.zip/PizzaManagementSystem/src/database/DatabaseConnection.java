package database;

import java.sql.*;

public class DatabaseConnection 
{
	public static Connection getConnection()
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pizzas_ordering_system", "root", "");
			System.out.println("Connected");
			return conn;
		}
		catch(Exception e)
		{
			System.out.println(e);
			
		}
		
		return null;
	}
	
	/*
	public static void main(String[] args)
	{
		DatabaseConnection db_conn = new DatabaseConnection();
		db_conn.getConnection();
	}
	*/
}
