package view;

import java.awt.EventQueue;

import java.sql.*;
import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JPanel;
import java.awt.SystemColor;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JMenuBar;
import java.awt.Canvas;
import java.awt.Label;
import javax.swing.SwingConstants;
import javax.swing.JPasswordField;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

import model.User;
import database.DatabaseConnection;
import controller.UserController;

public class LoginFrame extends JFrame{

	private JFrame frameSystem;
	private JTextField txtUsername;
	private JPasswordField txtPassword;
	
	DatabaseConnection db_conn = new DatabaseConnection();
	UserController userController = new UserController();
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginFrame window = new LoginFrame();
					window.frameSystem.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LoginFrame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() 
	{
		frameSystem = new JFrame();
		frameSystem.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Amirah\\Desktop\\PizzaManagementSystem\\img\\pizza.png"));
		frameSystem.setForeground(Color.WHITE);
		frameSystem.setFont(new Font("Arial", Font.PLAIN, 12));
		frameSystem.setTitle("PIZZA MANAGEMENT SYSTEM");
		frameSystem.setBackground(new Color(0, 0, 0));
		frameSystem.getContentPane().setBackground(new Color(0, 0, 0));
		frameSystem.getContentPane().setForeground(Color.BLACK);
		frameSystem.setBounds(100, 100, 800, 600);
		frameSystem.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frameSystem.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(220, 20, 60));
		panel.setBounds(0, 0, 784, 561);
		frameSystem.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.ORANGE);
		panel_1.setBounds(321, 0, 463, 561);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		txtUsername = new JTextField();
		txtUsername.setBounds(178, 286, 258, 35);
		panel_1.add(txtUsername);
		txtUsername.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("USERNAME");
		lblNewLabel.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 20));
		lblNewLabel.setBounds(35, 286, 143, 35);
		panel_1.add(lblNewLabel);
		
		JLabel lblPassword = new JLabel("PASSWORD");
		lblPassword.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 20));
		lblPassword.setBounds(35, 345, 143, 33);
		panel_1.add(lblPassword);
		
		JButton btnNewButton = new JButton("LOGIN");
		btnNewButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				//get the email and password
				User user = new User();
				user.setName(txtUsername.getText());
				user.setPassword(txtPassword.getText());
				
				try
				{
					
					boolean success = userController.logIn(user);
					if(txtUsername.getText().isEmpty())
					{
						JOptionPane.showMessageDialog(null, "Enter your username");
					}
					else if(txtPassword.getText().isEmpty())
					{
						JOptionPane.showMessageDialog(null, "Enter your password");
					}
					else if(success == true)
					{
						MenuFrame menuFrame = new MenuFrame();
						menuFrame.main(null);
						frameSystem.dispose();
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Invalid Username & password");
					}
					
				}
				catch(Exception e1)
				{
					System.out.println(e1);
				}

			}
		});
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(255, 69, 0));
		btnNewButton.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 20));
		btnNewButton.setBounds(293, 404, 143, 35);
		panel_1.add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("LOGIN");
		lblNewLabel_1.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 30));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(10, 154, 443, 35);
		panel_1.add(lblNewLabel_1);
		
		txtPassword = new JPasswordField();
		txtPassword.setBounds(178, 345, 258, 33);
		panel_1.add(txtPassword);
		
		JButton btnNewButton_1 = new JButton("FORGOT PASSWORD?");
		btnNewButton_1.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				ForgotPasswordFrame fpFrame = new ForgotPasswordFrame();
				fpFrame.main(null);
				
				frameSystem.dispose();
			}
		});
		btnNewButton_1.setBackground(new Color(154, 205, 50));
		btnNewButton_1.setForeground(new Color(255, 255, 255));
		btnNewButton_1.setHorizontalAlignment(SwingConstants.LEFT);
		btnNewButton_1.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 13));
		btnNewButton_1.setBounds(35, 404, 189, 35);
		panel_1.add(btnNewButton_1);
		
		JLabel lblNewLabel_4 = new JLabel("SYSTEM NAME");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(10, 50, 442, 50);
		panel_1.add(lblNewLabel_4);
		lblNewLabel_4.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 30));
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\Amirah\\Desktop\\PizzaManagementSystem\\img\\arrow_down.png"));
		lblNewLabel_2.setBounds(52, 181, 206, 200);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Does Not Have");
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setFont(new Font("Comic Sans MS", Font.BOLD, 25));
		lblNewLabel_3.setBounds(10, 71, 301, 50);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_3_1 = new JLabel("An Account?");
		lblNewLabel_3_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_1.setForeground(Color.WHITE);
		lblNewLabel_3_1.setFont(new Font("Comic Sans MS", Font.BOLD, 25));
		lblNewLabel_3_1.setBounds(10, 105, 301, 50);
		panel.add(lblNewLabel_3_1);
		
		JButton btnRegister = new JButton("REGISTER");
		btnRegister.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				RegFrame regFrame = new RegFrame();
				regFrame.main(null);
				
				frameSystem.dispose();
			}
		});
		btnRegister.setForeground(Color.BLACK);
		btnRegister.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 20));
		btnRegister.setBackground(Color.ORANGE);
		btnRegister.setBounds(52, 403, 206, 50);
		panel.add(btnRegister);
	}
}
