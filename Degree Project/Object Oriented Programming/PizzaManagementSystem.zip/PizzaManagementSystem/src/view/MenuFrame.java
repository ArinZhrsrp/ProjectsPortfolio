package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import controller.UserController;

import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JSpinner;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;

import database.DatabaseConnection;
import model.Orders;
import model.User;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MenuFrame {

	private JFrame menuFrame;
	DatabaseConnection db_conn = new DatabaseConnection();
	
	JComboBox comboSize = new JComboBox();
	JComboBox comboPizza = new JComboBox();
	JComboBox comboTopping = new JComboBox();
	JSpinner spinner = new JSpinner();
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuFrame window = new MenuFrame();
					window.menuFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MenuFrame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		User user = new User();
		menuFrame = new JFrame();
		menuFrame.addWindowListener(new WindowAdapter() 
		{
			@Override
			public void windowOpened(WindowEvent e)
			{
				pizzaComboBox();
				sizeComboBox();
				toppingComboBox();
			}
		});
		menuFrame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Amirah\\Desktop\\PizzaManagementSystem\\img\\pizza.png"));
		menuFrame.setTitle("PIZZA MANAGEMENT SYSTEM");
		menuFrame.getContentPane().setBackground(new Color(255, 69, 0));
		menuFrame.setBounds(100, 100, 800, 600);
		menuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		menuFrame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 150, 561);
		panel.setBackground(Color.WHITE);
		menuFrame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(0, 76, 129, 107);
		panel.add(lblNewLabel);
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Amirah\\Desktop\\PizzaManagementSystem\\img\\pep_pizza.png"));
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\Amirah\\Desktop\\PizzaManagementSystem\\img\\pine_pizza.png"));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1.setBounds(33, 219, 205, 149);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\Amirah\\Desktop\\PizzaManagementSystem\\img\\veggie_pizza.png"));
		lblNewLabel_2.setBounds(0, 379, 140, 121);
		panel.add(lblNewLabel_2);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(634, 0, 150, 561);
		menuFrame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\Amirah\\Desktop\\PizzaManagementSystem\\img\\olive.png"));
		lblNewLabel_3.setBounds(-61, 421, 176, 129);
		panel_1.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setIcon(new ImageIcon("C:\\Users\\Amirah\\Desktop\\PizzaManagementSystem\\img\\onion.png"));
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_4.setBounds(10, 283, 140, 129);
		panel_1.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setIcon(new ImageIcon("C:\\Users\\Amirah\\Desktop\\PizzaManagementSystem\\img\\shrimp.png"));
		lblNewLabel_5.setBounds(-61, 145, 201, 142);
		panel_1.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setIcon(new ImageIcon("C:\\Users\\Amirah\\Desktop\\PizzaManagementSystem\\img\\mozarella.png"));
		lblNewLabel_6.setBounds(10, 11, 140, 136);
		panel_1.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("MENU");
		lblNewLabel_7.setForeground(Color.WHITE);
		lblNewLabel_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_7.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 30));
		lblNewLabel_7.setBounds(160, 50, 464, 43);
		menuFrame.getContentPane().add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Choose Your Pizza :");
		lblNewLabel_8.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_8.setForeground(Color.WHITE);
		lblNewLabel_8.setFont(new Font("Comic Sans MS", Font.PLAIN, 18));
		lblNewLabel_8.setBounds(215, 104, 360, 31);
		menuFrame.getContentPane().add(lblNewLabel_8);
		

		comboPizza.setFont(new Font("Arial", Font.PLAIN, 14));
		comboPizza.setBounds(215, 137, 360, 31);
		menuFrame.getContentPane().add(comboPizza);
		
		JLabel lblNewLabel_8_1 = new JLabel("Choose Your Size & Crust :");
		lblNewLabel_8_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_8_1.setForeground(Color.WHITE);
		lblNewLabel_8_1.setFont(new Font("Comic Sans MS", Font.PLAIN, 18));
		lblNewLabel_8_1.setBounds(215, 179, 360, 31);
		menuFrame.getContentPane().add(lblNewLabel_8_1);
		
		
		comboSize.setFont(new Font("Arial", Font.PLAIN, 14));
		comboSize.setBounds(215, 214, 360, 31);
		menuFrame.getContentPane().add(comboSize);
		
		JLabel lblNewLabel_8_2 = new JLabel("Choose One Topping :");
		lblNewLabel_8_2.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_8_2.setForeground(Color.WHITE);
		lblNewLabel_8_2.setFont(new Font("Comic Sans MS", Font.PLAIN, 18));
		lblNewLabel_8_2.setBounds(215, 256, 360, 31);
		menuFrame.getContentPane().add(lblNewLabel_8_2);
		
		
		comboTopping.setFont(new Font("Arial", Font.PLAIN, 14));
		comboTopping.setBounds(215, 289, 360, 31);
		menuFrame.getContentPane().add(comboTopping);
		
		JButton btnNewButton = new JButton("ADD");
		btnNewButton.setBackground(Color.ORANGE);
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 18));
		btnNewButton.setBounds(215, 443, 360, 43);
		menuFrame.getContentPane().add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				
				int success2 = 0;
				UserController userController = new UserController();
				Orders order = new Orders();
				
				int status = 1;

				user.getId();
				order.setOrder_pizza(comboPizza.getSelectedIndex());
				order.setOrder_size(comboSize.getSelectedIndex());
				order.setOrder_topping(comboTopping.getSelectedIndex());
				order.setOrder_quantity(Integer.parseInt(spinner.getValue().toString()));
				order.setStatus(status);
				
				try
				{

					 if (comboPizza.getSelectedIndex()==-1)
					 {
						  JOptionPane.showMessageDialog(null, "Select Pizza");
					 }
					 else
					 {
						 
						 success2 = userController.insertOrder(user, order);
						 JOptionPane.showMessageDialog(null, "Insert");
					 }
					
				}
				catch(Exception e1)
				{
					System.out.println(e1);
				}
				
				int id =  user.getId();
				user.setId(id);
				//menuFrame.dispose();
			}
		});
		
		JLabel lblNewLabel_9 = new JLabel("(**Charge may apply)");
		lblNewLabel_9.setForeground(Color.WHITE);
		lblNewLabel_9.setFont(new Font("Comic Sans MS", Font.PLAIN, 14));
		lblNewLabel_9.setBounds(401, 262, 144, 21);
		menuFrame.getContentPane().add(lblNewLabel_9);
		
		JButton btnOrder = new JButton("MY ORDER");
		btnOrder.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
	
				int id = user.getId();
				user.setId(id);
				OrderFrame orderFrame = new OrderFrame();
				orderFrame.main(null);
				
				menuFrame.dispose();
			}
		});
		btnOrder.setForeground(Color.WHITE);
		btnOrder.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 18));
		btnOrder.setBackground(Color.DARK_GRAY);
		btnOrder.setBounds(215, 497, 359, 42);
		menuFrame.getContentPane().add(btnOrder);
		
		JLabel lblNewLabel_8_2_1 = new JLabel("Quantity : ");
		lblNewLabel_8_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_8_2_1.setForeground(Color.WHITE);
		lblNewLabel_8_2_1.setFont(new Font("Comic Sans MS", Font.PLAIN, 18));
		lblNewLabel_8_2_1.setBounds(215, 343, 165, 31);
		menuFrame.getContentPane().add(lblNewLabel_8_2_1);
		
		 spinner = new JSpinner();
		spinner.setFont(new Font("Arial", Font.PLAIN, 17));
		spinner.setBounds(390, 346, 72, 31);
		menuFrame.getContentPane().add(spinner);
	}
	
	public void pizzaComboBox()
	{
		Connection conn = db_conn.getConnection();
		
		try 
		{
			String q_pizza = "SELECT * FROM pizza";
			PreparedStatement stmt = conn.prepareStatement(q_pizza);
			ResultSet res = stmt.executeQuery();
			
			while(res.next())
			{
				comboPizza.addItem(res.getString("pizza_name"));
			}
			
			res.close();
			stmt.close();
			conn.close();
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
	}
	
	public void sizeComboBox()
	{
		Connection conn = db_conn.getConnection();
		
		try 
		{
			String q_size = "SELECT * FROM size_crust";
			PreparedStatement stmt = conn.prepareStatement(q_size);
			ResultSet res = stmt.executeQuery();
			
			while(res.next())
			{
				comboSize.addItem(res.getString("sc_name"));
			}
			
			res.close();
			stmt.close();
			conn.close();
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
	}
	
	public void toppingComboBox()
	{
		Connection conn = db_conn.getConnection();
		
		try 
		{
			String q_topping = "SELECT * FROM topping";
			PreparedStatement stmt = conn.prepareStatement(q_topping);
			ResultSet res = stmt.executeQuery();
			
			while(res.next())
			{
				comboTopping.addItem(res.getString("topping_name"));
			}
			
			res.close();
			stmt.close();
			conn.close();
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
	}
}
