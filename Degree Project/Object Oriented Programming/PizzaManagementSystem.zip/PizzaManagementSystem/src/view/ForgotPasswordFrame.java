package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;

import controller.UserController;
import database.DatabaseConnection;
import model.User;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ForgotPasswordFrame {

	private JFrame forgotPasswordFrame;
	private JTextField textFieldEmail;
	private JPasswordField passwordFieldNew;
	private JPasswordField passwordFieldConfirm;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ForgotPasswordFrame window = new ForgotPasswordFrame();
					window.forgotPasswordFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ForgotPasswordFrame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		forgotPasswordFrame = new JFrame();
		forgotPasswordFrame.setTitle("PIZZA MANAGEMENT SYSTEM");
		forgotPasswordFrame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Amirah\\Desktop\\PizzaManagementSystem\\img\\pizza.png"));
		forgotPasswordFrame.setBounds(100, 100, 800, 600);
		forgotPasswordFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		forgotPasswordFrame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.ORANGE);
		panel.setBounds(0, 0, 784, 561);
		forgotPasswordFrame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblForgotPassword = new JLabel("FORGOT PASSWORD?");
		lblForgotPassword.setHorizontalAlignment(SwingConstants.CENTER);
		lblForgotPassword.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 30));
		lblForgotPassword.setBounds(10, 80, 412, 43);
		panel.add(lblForgotPassword);
		
		JLabel lblEmail_1 = new JLabel("EMAIL");
		lblEmail_1.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 18));
		lblEmail_1.setBounds(52, 174, 143, 35);
		panel.add(lblEmail_1);
		
		textFieldEmail = new JTextField();
		textFieldEmail.setColumns(10);
		textFieldEmail.setBounds(50, 205, 331, 35);
		panel.add(textFieldEmail);
		
		JButton btnNewButton = new JButton("SUBMIT");
		btnNewButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				DatabaseConnection db_conn = new DatabaseConnection();
				UserController userController = new UserController();
				
				//get the email and password
				User user = new User();
				user.setEmail(textFieldEmail.getText());
				user.setPassword(passwordFieldNew.getText());
				
				try
				{
					
					
					if(textFieldEmail.getText().isEmpty())
					{
						JOptionPane.showMessageDialog(null, "Enter your email");
					}
					else if(passwordFieldNew.getText().isEmpty())
					{
						JOptionPane.showMessageDialog(null, "Enter your new password");
					}
					else if(passwordFieldConfirm.getText().isEmpty())
					{
						JOptionPane.showMessageDialog(null, "Enter your new confirm password");
					}
					
					else if(passwordFieldConfirm.getText().equals(passwordFieldNew.getText()))
					{
						userController.findEmail(user);
						LoginFrame loginFrame = new LoginFrame();
						loginFrame.main(null);
						
						forgotPasswordFrame.dispose();
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Password missmatch");
					}
					
				}
				catch(Exception e1)
				{
					System.out.println(e1);
				}
			}
		});
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 20));
		btnNewButton.setBackground(Color.RED);
		btnNewButton.setBounds(231, 419, 150, 35);
		panel.add(btnNewButton);
		
		JLabel lblEmail_1_1 = new JLabel("NEW PASSWORD");
		lblEmail_1_1.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 18));
		lblEmail_1_1.setBounds(54, 251, 193, 35);
		panel.add(lblEmail_1_1);
		
		JLabel lblEmail_1_2 = new JLabel("CONFIRM PASSWORD");
		lblEmail_1_2.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 18));
		lblEmail_1_2.setBounds(54, 328, 217, 35);
		panel.add(lblEmail_1_2);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(250, 128, 114));
		panel_1.setBounds(453, 0, 331, 561);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Java\\oop_pms\\PizzaManagementSystem\\img\\forgot_pwd.png"));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(10, 11, 311, 539);
		panel_1.add(lblNewLabel);
		
		passwordFieldNew = new JPasswordField();
		passwordFieldNew.setBounds(52, 282, 329, 35);
		panel.add(passwordFieldNew);
		
		passwordFieldConfirm = new JPasswordField();
		passwordFieldConfirm.setBounds(52, 359, 329, 35);
		panel.add(passwordFieldConfirm);
		
		JButton btnNewButton_1 = new JButton("BACK");
		btnNewButton_1.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				LoginFrame loginFrame = new LoginFrame();
				loginFrame.main(null);
				
				forgotPasswordFrame.dispose();
			}
		});
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setBackground(new Color(154, 205, 50));
		btnNewButton_1.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 18));
		btnNewButton_1.setBounds(52, 419, 89, 32);
		panel.add(btnNewButton_1);
	}
}
