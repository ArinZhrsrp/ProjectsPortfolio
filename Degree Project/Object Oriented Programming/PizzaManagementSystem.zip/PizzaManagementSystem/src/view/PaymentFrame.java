package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.awt.event.ActionEvent;

import database.DatabaseConnection;
import model.Payment;
import model.User;
import controller.UserController;
import java.sql.*;
import java.util.Calendar;

import javax.swing.JScrollPane;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class PaymentFrame {

	private JFrame paymentFrame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextArea newReceiptTxt;
	private JPanel panel_2 = new JPanel();
	private JPanel panel_1 = new JPanel();
	DatabaseConnection db_conn = new DatabaseConnection();
	UserController userController = new UserController();
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PaymentFrame window = new PaymentFrame();
					window.paymentFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PaymentFrame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		paymentFrame = new JFrame();
		paymentFrame.setIconImage(Toolkit.getDefaultToolkit().getImage("/Users/shiwwinzahra/Downloads/SEM1 /BITP 3113/PizzaManagementSystem 4.34.03 AM/img/pizza.png"));
		paymentFrame.setTitle("PIZZA MANAGEMENT SYSTEM");
		paymentFrame.setBounds(100, 100, 800, 600);
		paymentFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		paymentFrame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(154, 205, 50));
		panel.setBounds(0, 0, 784, 561);
		paymentFrame.getContentPane().add(panel);
		panel.setLayout(null);
		
		panel_1.setBackground(Color.ORANGE);
		panel_1.setBounds(333, 0, 451, 561);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("RECEIPT");
		lblNewLabel_1.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 30));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(10, 50, 421, 36);
		panel_1.add(lblNewLabel_1);
		
		JButton btnMenu = new JButton("MENU");
		btnMenu.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				MenuFrame menuFrame = new MenuFrame();
				menuFrame.main(null);
				
				paymentFrame.dispose();
			}
		});
		btnMenu.setForeground(Color.WHITE);
		btnMenu.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 20));
		btnMenu.setBackground(new Color(154, 205, 50));
		btnMenu.setBounds(30, 446, 157, 37);
		panel_1.add(btnMenu);
		
		JButton btnPrint = new JButton("PRINT");
		btnPrint.setEnabled(false);
		btnPrint.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try {
					userController.receiptTextArea().print();
				} 
				catch (PrinterException e1) 
				{
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnPrint.setForeground(Color.WHITE);
		btnPrint.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 20));
		btnPrint.setBackground(new Color(255, 69, 0));
		btnPrint.setBounds(274, 446, 157, 37);
		panel_1.add(btnPrint);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 97, 421, 338);
		panel_1.add(scrollPane);
		scrollPane.setViewportView(panel_2);
		
		
		panel_2.setBackground(Color.WHITE);
		
		JButton btnLogOut = new JButton("LOG OUT");
		btnLogOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LoginFrame login = new LoginFrame();
				login.main(null);
				
				paymentFrame.dispose();
			}
		});
		btnLogOut.setForeground(Color.WHITE);
		btnLogOut.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 20));
		btnLogOut.setBackground(new Color(154, 205, 50));
		btnLogOut.setBounds(30, 513, 401, 37);
		panel_1.add(btnLogOut);
		
		JLabel lblNewLabel = new JLabel("PAYMENT");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 30));
		lblNewLabel.setBounds(10, 50, 313, 37);
		panel.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setFont(new Font("Courier New", Font.BOLD, 17));
		textField.setBackground(Color.WHITE);
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setBounds(93, 212, 127, 37);
		panel.add(textField);
		textField.setColumns(10);
		try {
			textField.setText(userController.calc());
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		JLabel lblNewLabel_2 = new JLabel("TOTAL PRICE (RM) : ");
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("Comic Sans MS", Font.BOLD, 18));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(10, 164, 313, 37);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("AMOUNT PAID (RM) :");
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setFont(new Font("Comic Sans MS", Font.BOLD, 18));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(10, 292, 313, 37);
		panel.add(lblNewLabel_3);
		
		textField_1 = new JTextField();
		textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		textField_1.setFont(new Font("Courier New", Font.BOLD, 17));
		textField_1.setBackground(Color.WHITE);
		textField_1.setBounds(93, 340, 127, 37);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnNewButton = new JButton("PAY");
		btnNewButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				double paid = Double.parseDouble(textField_1.getText());
				double price = Double.parseDouble(textField.getText());
				
				if(paid < price)
				{
					JOptionPane.showMessageDialog(null, "Insufficient amount");
				}
				else
				{
					
					try 
					{
						int userId;
						String sql2 =  "SELECT * FROM currLogin WHERE currLogin_id = 1";
						
						//1. Connection 
						Connection conn = DatabaseConnection.getConnection();
						
						//2. PreparedStatement
						PreparedStatement preparedStatement = conn.prepareStatement(sql2);
						
						//3. View or insert/update
						ResultSet resultSet = preparedStatement.executeQuery();
						
						if(resultSet.next())
						{
							int id = resultSet.getInt("currLogin_userId");
							userId = id;
						
							
							// Insert data into the payment table
						    String sql = "INSERT INTO payment (payment_orders, payment_price, payment_paid, payment_date) VALUES (?,?,?,?)";
						    PreparedStatement paymentStatement = conn.prepareStatement(sql);
						    paymentStatement.setInt(1, userId);
						    paymentStatement.setDouble(2, price);
						    paymentStatement.setDouble(3, paid);
						    Calendar calendar = Calendar.getInstance();
						    Timestamp currentTimestamp = new Timestamp(calendar.getTimeInMillis());
						    paymentStatement.setTimestamp(4, currentTimestamp);
						    int rowsInserted = paymentStatement.executeUpdate();
						    paymentStatement.close();

						   
							
							newReceiptTxt = userController.receiptTextArea();
							panel_2.add(newReceiptTxt);
							
							btnPrint.setEnabled(true);
							
							
						}
						
						//4. Must close the connection
						conn.close();
					}
					
					catch(Exception ex)
					{
						System.out.println("error : " + ex);
					}
					
				}
			
			}
		});
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(250, 128, 114));
		btnNewButton.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 20));
		btnNewButton.setBounds(10, 419, 313, 37);
		panel.add(btnNewButton);
		
		JButton btnCancel = new JButton("CANCEL");
		btnCancel.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				OrderFrame orderFrame = new OrderFrame();
				orderFrame.main(null);
				
				paymentFrame.dispose();
			}
		});
		btnCancel.setForeground(Color.WHITE);
		btnCancel.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 20));
		btnCancel.setBackground(new Color(255, 0, 0));
		btnCancel.setBounds(10, 470, 313, 37);
		panel.add(btnCancel);
	}
}
