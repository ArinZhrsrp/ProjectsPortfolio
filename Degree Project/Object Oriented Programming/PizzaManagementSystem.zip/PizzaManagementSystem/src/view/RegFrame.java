package view;

import java.awt.EventQueue;

import java.awt.Image;
import java.io.IOException;
import java.net.URL;
import javax.swing.JFrame;
import java.awt.Toolkit;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JTextArea;
import javax.swing.JComboBox;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import database.DatabaseConnection;
import controller.UserController;
import model.User;
import model.UserAddress;

public class RegFrame extends JFrame{

	private JFrame registerFrame;
	private JTextField textEmail;
	private JPasswordField textPassword;
	private JTextField textName;
	private JTextField textPhoneNo;
	private JTextField textCity;
	private JTextField textPostcode;
	
	//JComboBox comboState = new JComboBox();
	JComboBox comboState = new JComboBox();
	JTextArea textAddress = new JTextArea();
	DatabaseConnection db_conn = new DatabaseConnection();
	User user = new User();
	UserAddress userAddress = new UserAddress();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegFrame window = new RegFrame();
					window.registerFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RegFrame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		registerFrame = new JFrame();
		registerFrame.addWindowListener(new WindowAdapter() 
		{
			@Override
			public void windowOpened(WindowEvent e) 
			{
				stateComboBox();
			}
		});
		
		Image imageIcon = null;
        try {
            URL url = new URL("https://cdn-icons-png.flaticon.com/512/3132/3132693.png");
            imageIcon = ImageIO.read(url);
        } catch (IOException e) {
        	e.printStackTrace();
        }
		
		registerFrame.setTitle("PIZZA MANAGEMENT SYSTEM");
		registerFrame.setIconImage(imageIcon);
		registerFrame.setBounds(100, 100, 800, 600);
		registerFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		registerFrame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.ORANGE);
		panel.setBounds(0, 0, 784, 561);
		registerFrame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("USER REGISTRATION");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 30));
		lblNewLabel.setBounds(10, 50, 528, 43);
		panel.add(lblNewLabel);
		
		JLabel lblEmail = new JLabel("EMAIL");
		lblEmail.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 18));
		lblEmail.setBounds(35, 300, 143, 35);
		panel.add(lblEmail);
		
		textEmail = new JTextField();
		textEmail.setColumns(10);
		textEmail.setBounds(35, 329, 258, 35);
		panel.add(textEmail);
		
		JLabel lblPassword_1 = new JLabel("PASSWORD");
		lblPassword_1.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 18));
		lblPassword_1.setBounds(35, 377, 143, 33);
		panel.add(lblPassword_1);
		
		textPassword = new JPasswordField();
		textPassword.setBounds(35, 405, 258, 33);
		panel.add(textPassword);
		
		
		JButton btnNewButton = new JButton("REGISTER");
		btnNewButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				user.setEmail(textEmail.getText().trim());
				user.setName(textName.getText());
				user.setPassword(textPassword.getText());
				user.setPhoneNo(textPhoneNo.getText());
				userAddress.setAddress(textAddress.getText());
				userAddress.setCity(textCity.getText());
				userAddress.setPostcode(textPostcode.getText());
				userAddress.setState(comboState.getSelectedItem().toString());
				
				UserController userController = new UserController();
				
				try 
				{
					int success = 0;
					int success2 = 0;
					
					
					if(textName.getText().isEmpty() )
					{
						JOptionPane.showMessageDialog(null, "Please enter your name...");
						
					}
					else if(textPhoneNo.getText().isEmpty() )
					{
						JOptionPane.showMessageDialog(null, "Please enter your phone number...");
						
					}
					else if(textEmail.getText().isEmpty() )
					{
						JOptionPane.showMessageDialog(null, "Please enter your email...");
						
					}
					else if(textPassword.getText().isEmpty() )
					{
						JOptionPane.showMessageDialog(null, "Please enter your password...");
						
					}
					else if(textAddress.getText().isEmpty() )
					{
						JOptionPane.showMessageDialog(null, "Please enter your address...");
						
					}
					else if(textCity.getText().isEmpty() )
					{
						JOptionPane.showMessageDialog(null, "Please enter your City...");
						
					}
					else if(textPostcode.getText().isEmpty() )
					{
						JOptionPane.showMessageDialog(null, "Please enter your Postcode...");
						
					}
					else if(comboState.getSelectedIndex() == 0 )
					{
						JOptionPane.showMessageDialog(null, "Please enter your state...");
						
					}
					else if(success == -1 && success2 == -1)
					{
						JOptionPane.showMessageDialog(null, "User is already Exist!");
					}
					else
					{
						
						 success = userController.insertUser(user);
						 success2 = userController.insertUserAddress(user, userAddress);
						 System.out.println("Success "+success);
						 System.out.println("Success "+success2);
						
						JOptionPane.showMessageDialog(null, "User is successfully registered");
						textEmail.setText("");
						textName.setText("");
						textPassword.setText("");
						textPhoneNo.setText("");
						textAddress.setText("");
						textCity.setText("");
						textPostcode.setText("");
						comboState.setSelectedIndex(0);
						registerFrame.dispose();
						LoginFrame loginFrame = new LoginFrame();
						loginFrame.main(null);
//						
					}
				} 
				catch (Exception e1) 
				{
					System.out.println(e1);
				}
						
			}
		});
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 20));
		btnNewButton.setBackground(Color.RED);
		btnNewButton.setBounds(596, 479, 150, 35);
		panel.add(btnNewButton);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				LoginFrame loginFrame = new LoginFrame();
				loginFrame.main(null);
				
				registerFrame.dispose();
			}
		});
		btnBack.setForeground(Color.WHITE);
		btnBack.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 20));
		btnBack.setBackground(new Color(154, 205, 50));
		btnBack.setBounds(35, 479, 150, 35);
		panel.add(btnBack);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\Amirah\\Desktop\\PizzaManagementSystem\\img\\pizza_whole.png"));
		lblNewLabel_1.setBounds(527, 26, 200, 158);
		panel.add(lblNewLabel_1);
		
		JLabel lblName = new JLabel("NAME");
		lblName.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 18));
		lblName.setBounds(35, 149, 143, 35);
		panel.add(lblName);
		
		textName = new JTextField();
		textName.setColumns(10);
		textName.setBounds(35, 178, 258, 35);
		panel.add(textName);
		
		JLabel lblEmail_2 = new JLabel("PHONE NO");
		lblEmail_2.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 18));
		lblEmail_2.setBounds(35, 225, 143, 35);
		panel.add(lblEmail_2);
		
		textPhoneNo = new JTextField();
		textPhoneNo.setColumns(10);
		textPhoneNo.setBounds(35, 254, 258, 35);
		panel.add(textPhoneNo);
		
		JLabel lblAddress = new JLabel("ADDRESS");
		lblAddress.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 18));
		lblAddress.setBounds(383, 194, 143, 35);
		panel.add(lblAddress);
		
		JLabel lblCity = new JLabel("CITY");
		lblCity.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 18));
		lblCity.setBounds(383, 299, 143, 35);
		panel.add(lblCity);
		
		textCity = new JTextField();
		textCity.setColumns(10);
		textCity.setBounds(383, 328, 363, 35);
		panel.add(textCity);
		
		JLabel lblPostcode = new JLabel("POSTCODE");
		lblPostcode.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 18));
		lblPostcode.setBounds(383, 374, 143, 35);
		panel.add(lblPostcode);
		
		textPostcode = new JTextField();
		textPostcode.setColumns(10);
		textPostcode.setBounds(383, 403, 115, 35);
		panel.add(textPostcode);
		
		JLabel lblState = new JLabel("STATE");
		lblState.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 18));
		lblState.setBounds(514, 374, 234, 35);
		panel.add(lblState);
		
		
		textAddress.setBounds(383, 223, 363, 65);
		panel.add(textAddress);
		
		
		comboState.setBackground(Color.WHITE);
		comboState.setBounds(508, 403, 238, 35);
		panel.add(comboState);
	}
	
	public void stateComboBox()
	{
		Connection conn = db_conn.getConnection();
		
		try 
		{
			String q_state = "SELECT * FROM state";
			PreparedStatement stmt = conn.prepareStatement(q_state);
			ResultSet res = stmt.executeQuery();
			
			while(res.next())
			{
				comboState.addItem(res.getString("state_name"));
			}
			
			res.close();
			stmt.close();
			conn.close();
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
	}
}
