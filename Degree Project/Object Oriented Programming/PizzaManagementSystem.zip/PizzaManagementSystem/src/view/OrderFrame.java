package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import controller.UserController;

import java.awt.Font;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import database.DatabaseConnection;
import model.User;

import javax.swing.JScrollPane;

public class OrderFrame {

	private JFrame orderFrame;
	private JTable table;
	
	DatabaseConnection db_conn = new DatabaseConnection();
	UserController userController = new UserController();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OrderFrame window = new OrderFrame();
					window.orderFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public OrderFrame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		orderFrame = new JFrame();
		orderFrame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowOpened(WindowEvent e) 
			{
				try {
					showData();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		orderFrame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Amirah\\Desktop\\PizzaManagementSystem\\img\\pizza.png"));
		orderFrame.setTitle("PIZZA MANAGEMENT SYSTEM");
		orderFrame.setBounds(100, 100, 800, 600);
		orderFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		orderFrame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.ORANGE);
		panel.setBounds(0, 0, 784, 561);
		orderFrame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 0, 0));
		panel_1.setBounds(0, 0, 70, 561);
		panel.add(panel_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 0, 0));
		panel_2.setBounds(714, 0, 70, 561);
		panel.add(panel_2);
		
		JLabel lblNewLabel = new JLabel("MY ORDER");
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 30));
		lblNewLabel.setBounds(80, 50, 624, 35);
		panel.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("MENU");
		btnNewButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				MenuFrame menuFrame = new MenuFrame();
				menuFrame.main(null);
				
				orderFrame.dispose();
			}
		});
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBackground(new Color(154, 205, 50));
		btnNewButton.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 17));
		btnNewButton.setBounds(80, 424, 150, 38);
		panel.add(btnNewButton);
		
		
		JButton btnNewButton_2 = new JButton("REMOVE");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				Connection conn = db_conn.getConnection();
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				
				if(table.getSelectedRowCount() == 1)
				{
					int row =  table.convertRowIndexToModel(table.getSelectedRow());
		            int col = table.getColumnModel().getColumnIndex("No");

		            int orderId = (Integer) table.getModel().getValueAt(row, col);
		           
					try
					{
						String q_delete = "DELETE FROM orders WHERE order_id = " + orderId;
						Statement st = conn.createStatement();
						st.executeUpdate(q_delete);
						
						st.close();
						conn.close();
						
						model.removeRow(table.getSelectedRow());
					}
					catch(Exception ex)
					{
						System.out.println("error : " + ex);
					}
				}
				else
				{
					if(table.getRowCount() == 0)
					{
						JOptionPane.showMessageDialog(null, "No Data");
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Please Select Single Data");
					}
				}
			}
		});
		btnNewButton_2.setForeground(Color.WHITE);
		btnNewButton_2.setBackground(new Color(255, 0, 0));
		btnNewButton_2.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 17));
		btnNewButton_2.setBounds(554, 424, 150, 38);
		panel.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("PROCEED TO PAYMENT");
		btnNewButton_3.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				PaymentFrame paymentFrame = new PaymentFrame();
				paymentFrame.main(null);
				
				orderFrame.dispose();
			}
		});
		btnNewButton_3.setForeground(Color.WHITE);
		btnNewButton_3.setBackground(new Color(250, 128, 114));
		btnNewButton_3.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 17));
		btnNewButton_3.setBounds(80, 488, 624, 38);
		panel.add(btnNewButton_3);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(80, 96, 624, 288);
		panel.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
	}
	
	public void showData() throws ClassNotFoundException, SQLException
	{
		int userId;
		String sql =  "SELECT * FROM currLogin WHERE currLogin_id = 1";
		
		//1. Connection 
		Connection conn = DatabaseConnection.getConnection();
		
		//2. PreparedStatement
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		
		//3. View or insert/update
		ResultSet resultSet = preparedStatement.executeQuery();
		
		if(resultSet.next())
		{
			int id = resultSet.getInt("currLogin_userId");
			userId = id;
		
			
			DefaultTableModel model = new DefaultTableModel();
			model.addColumn("No");
			model.addColumn("Pizza");
			model.addColumn("Size & Crust");
			model.addColumn("Topping");
			model.addColumn("Quantity");
			
			try
			{
				String q_order = "SELECT * FROM orders WHERE status = 1 AND order_user = '"+ userId +"'";
				Statement st = conn.createStatement();
				ResultSet rs = st.executeQuery(q_order);
				
				while(rs.next())
				{
					model.addRow(new Object []
							{
									rs.getInt("order_id"),
									rs.getString("order_pizza"),
									rs.getString("order_size_crust"),
									rs.getString("order_topping"),
									rs.getString("order_quantity")
							});
				}
				
				rs.close();
				st.close();
				conn.close();
				
				table.setModel(model);
				table.setAutoResizeMode(0);
				table.getColumnModel().getColumn(0).setPreferredWidth(60);
				table.getColumnModel().getColumn(1).setPreferredWidth(200);
				table.getColumnModel().getColumn(2).setPreferredWidth(80);
				table.getColumnModel().getColumn(3).setPreferredWidth(200);
				table.getColumnModel().getColumn(4).setPreferredWidth(80);
				
			}
			catch(Exception ex)
			{
				System.out.println("error : " + ex);
			}
			
			
		}
		
		//4. Must close the connection
		conn.close();
		
	}
	
	
}