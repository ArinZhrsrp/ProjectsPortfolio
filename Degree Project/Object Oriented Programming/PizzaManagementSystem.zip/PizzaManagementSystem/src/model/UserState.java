package model;

public class UserState {
	private String State;

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}
	

}
