package model;

public class Topping {
	
	private String toppingname;
	private double toppingcharge;
	
	public String getToppingname() {
		return toppingname;
	}
	public void setToppingname(String toppingname) {
		this.toppingname = toppingname;
	}
	public double getToppingcharge() {
		return toppingcharge;
	}
	public void setToppingcharge(double toppingcharge) {
		this.toppingcharge = toppingcharge;
	}

}
