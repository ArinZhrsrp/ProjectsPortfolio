package model;

public class Pizza {
	private String pizzaname;

	public String getPizzaname() {
		return pizzaname;
	}

	public void setPizzaname(String pizzaname) {
		this.pizzaname = pizzaname;
	}

}
