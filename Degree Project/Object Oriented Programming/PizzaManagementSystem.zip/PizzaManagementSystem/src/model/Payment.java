package model;

import java.time.LocalDateTime;

public class Payment {
	
	private int paymentuserid;
	private double paymentprice;
	private double paymentpaid;
	
	public int getPaymentuserid() {
		return paymentuserid;
	}
	public void setPaymentuserid(int paymentuserid) {
		this.paymentuserid = paymentuserid;
	}
	public double getPaymentprice() {
		return paymentprice;
	}
	public void setPaymentprice(double paymentprice) {
		this.paymentprice = paymentprice;
	}
	public double getPaymentpaid() {
		return paymentpaid;
	}
	public void setPaymentpaid(double paymentpaid) {
		this.paymentpaid = paymentpaid;
	}
	public LocalDateTime getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(LocalDateTime paymentDate) {
		this.paymentDate = paymentDate;
	}
	private LocalDateTime paymentDate;

}
