package model;

public class SizeCrust {
	
	private String scname;
	private double scprice;
	public String getScname() {
		return scname;
	}
	public void setScname(String scname) {
		this.scname = scname;
	}
	public double getScprice() {
		return scprice;
	}
	public void setScprice(double scprice) {
		this.scprice = scprice;
	}

}
