package model;

public class Orders {
	
	private int order_pizza;
	private int order_size;
	private int order_topping;
	private int order_quantity;
	private int status;
	private User userid;
	
	public User getUserid() {
		return userid;
	}
	public void setUserid(User userid) {
		this.userid = userid;
	}
	public int getOrder_pizza() {
		return order_pizza;
	}
	public void setOrder_pizza(int i) {
		this.order_pizza = i;
	}
	public int getOrder_size() {
		return order_size;
	}
	public void setOrder_size(int i) {
		this.order_size = i;
	}


	public int getOrder_topping() {
		return order_topping;
	}
	public void setOrder_topping(int i) {
		this.order_topping = i;
	}
	public int getOrder_quantity() {
		return order_quantity;
	}
	public void setOrder_quantity(int order_quantity) {
		this.order_quantity = order_quantity;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status2) {
		this.status = status2;
	}
	

}
