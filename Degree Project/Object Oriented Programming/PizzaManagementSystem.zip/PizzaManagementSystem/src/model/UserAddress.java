package model;

public class UserAddress 
{
	private String Address;
	private String City;
	private String Postcode;
	private String state;
	
	public String getAddress() 
	{
		return Address;
	}
	public void setAddress(String address) 
	{
		Address = address;
	}
	
	public String getCity() 
	{
		return City;
	}
	public void setCity(String city) 
	{
		City = city;
	}
	
	public String getPostcode() 
	{
		return Postcode;
	}
	public void setPostcode(String postcode) 
	{
		Postcode = postcode;
	}
	
	public String getState()
	{
		return state;
	}
	public void setState(String state)
	{
		this.state = state;
	}

}
