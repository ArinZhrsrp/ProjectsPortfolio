module PizzaManagementSystem 
{
	requires java.desktop;
	requires java.sql;
	requires java.net.http;
}