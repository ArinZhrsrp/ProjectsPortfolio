package w2.g16.odds.browsing;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ProductViewHolder extends RecyclerView.ViewHolder {


    public ProductViewHolder(@NonNull View itemView) {
        super(itemView);
    }
}
