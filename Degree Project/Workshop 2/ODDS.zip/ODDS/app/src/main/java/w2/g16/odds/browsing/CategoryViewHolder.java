package w2.g16.odds.browsing;

/*public class CategoryViewHolder extends RecyclerView.ViewHolder {

    private final ImageView imgCategory;
    private final TextView tvCategory;

    public CategoryViewHolder(@NonNull View itemView) {
        super(itemView);
        this.imgCategory = itemView.findViewById(R.id.img_category);
        this.tvCategory = itemView.findViewById(R.id.tv_category);
    }

    public void setCategory(Category category) {
        Picasso.get()
                .load(category.getImg())
                .into(imgCategory);
        tvCategory.setText(category.getCategoryName());
    }
}*/
