//package w2.g16.odds.ordering;
//
//import android.view.View;
//import android.widget.EditText;
//import android.widget.ImageView;
//import android.widget.TextView;
//
//import androidx.annotation.NonNull;
//import androidx.recyclerview.widget.RecyclerView;
//
//import com.squareup.picasso.Picasso;
//
//import w2.g16.odds.model.Cart;
//import w2.g16.odds.model.Products;
//import w2.g16.odds.R;
//import w2.g16.odds.model.Shop;
//
//public class CartViewHolder extends RecyclerView.ViewHolder {
//
//    private final TextView tvShopname;
////            , tvName, tvVariation, tvPrice, quantity;
////    private final ImageView img;
//
//    public CartViewHolder(@NonNull View itemView) {
//        super(itemView);
//        this.tvShopname = itemView.findViewById(R.id.tv_shopname);
////        this.tvName = itemView.findViewById(R.id.tv_product_name);
////        this.tvPrice = itemView.findViewById(R.id.tv_price);
////        this.tvVariation = itemView.findViewById(R.id.tv_variation);
////        this.quantity = itemView.findViewById(R.id.txt_quantity);
////        this.img = itemView.findViewById(R.id.img_product);
//    }
//
//    public void setShop(Shop shop) {
//        tvShopname.setText(shop.getShopname());
////        tvName.setText(cart.getProduct_name());
////        tvPrice.setText(cart.getPrice());
////        tvVariation.setText(cart.getVariation_type());
////        quantity.setText(cart.getQuantity());
////        Picasso.get()
////                .load(cart.getImage())
////                .into(img);
//    }
//}
