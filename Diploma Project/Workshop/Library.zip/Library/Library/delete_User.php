<html>
<head>
<title>DELETE USER</title>
<link rel="stylesheet" type="text/css" href="library.css">
</head>

<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;background-attachment: fixed">

<?php
 
    include("admin_head.php");
    include_once 'inc/connect.php';

    
$sql = "DELETE FROM user WHERE userid='" . $_GET["id"] . "'";
if (mysqli_query($conn, $sql)) {
    echo "Record deleted successfully";
    echo "<meta http-equiv=\"refresh\"content=\"3;URL=user.php\">";
} else {
    echo "Error deleting record: " . mysqli_error($conn);
    echo "<meta http-equiv=\"refresh\"content=\"3;URL=user.php\">";
}
?>

<?php
    include("footer.php");
?>
       

</body>