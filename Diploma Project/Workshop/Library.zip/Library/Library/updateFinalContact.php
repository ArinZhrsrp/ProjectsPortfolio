<html>
<head>
<title>UPDATE BOOK</title>
</head>

<body>

<?php
session_start();

include("admin_head.php");
include('inc/connect.php');

$id = $_REQUEST['u_id'];
$status = $_POST['u_status'];

$sql = "UPDATE contact SET status='".$status."' where contactid = '$id'";

$result = $conn->query($sql);


if($conn->query($sql) === TRUE) {
	echo"<p style = 'text-align:center'>Issue Has Been Updated!";
	echo "<meta http-equiv=\"refresh\"content=\"3;URL=viewIssue.php\">";
	echo "</p>";
} else {
	echo "<p>";
	echo"<p style = 'text-align:center'>ERROR: " .$sql. "<br>" . $conn->error;
	echo "</p>";
}
 //closes specified connection
$conn->close();
include('footer.php');
?>