<html>
<head>
<title>REGISTER BOOK</title>
<link rel="stylesheet" type="text/css" href="library.css">
</head>

<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;background-attachment: fixed">

<?php
    include("admin_head.php");
?>

<br/>
<div class="container">

      <form action="member_book.php" method="POST"  enctype='multipart/form-data'>
      <div class="container">
        <h1>Register</h1>
        <p>Please fill in this form to create a book.</p>
        <hr>

        <p><label for="fileToUpload"><b>Book Image</b></label></p>
        <p><input type='file' name='fileToUpload' required></p>

        <label for="isbn"><b>ISBN</b></label>
        <input type="text" placeholder="Enter ISBN" name="isbn" required>

        <p><label for="category"><b>Category &nbsp</b></label></p>
        <p>
        <input type="radio" name="category" value="Action" checked>Action
        <input type="radio" name="category" value="Adventure" >Adventure 
        <input type="radio" name="category" value="Art" >Art 
        <input type="radio" name="category" value="Autobiography" >Autobiography
        <input type="radio" name="category" value="Dictionary" >Dictionary 
        <input type="radio" name="category" value="Drama" >Drama
        <input type="radio" name="category" value="Encyclopedia" >Encyclopedia 
        <input type="radio" name="category" value="Fantasy" >Fantasy
        <input type="radio" name="category" value="Guide" >Guide 
        <input type="radio" name="category" value="Journal" >Journal 
        <input type="radio" name="category" value="History" >History
        <input type="radio" name="category" value="Horror" >Horror 
        <input type="radio" name="category" value="Religion" >Religion 
        <input type="radio" name="category" value="Review" >Review 
        <input type="radio" name="category" value="Romance" >Romance
        <input type="radio" name="category" value="Science Fiction" >Science Fiction 
        <input type="radio" name="category" value="Suspense" >Suspense
        <input type="radio" name="category" value="Textbook" >Textbook 
        <input type="radio" name="category" value="Thriller" >Thriller 
        <input type="radio" name="category" value="Travel" >Travel 
        <input type="radio" name="category" value="True Crime" >True Crime</p>
        


        <label for="title"><b>Title</b></label>
        <input type="text" placeholder="Enter Title" name="title" required>

        <label for="author"><b>Author</b></label>
        <input type="text" placeholder="Enter Author" name="author" required>

        <label for="publisher"><b>Publisher</b></label>
        <input type="text" placeholder="Enter Publisher" name="publisher" required>

        <label for="pages"><b>Pages</b></label>
        <input type="text" placeholder="Enter Pages" name="pages" required>

        
        <label for="detail"><b>Detail</b></label>
        <textarea rows="20" cols="500" name="detail" placeholder="Enter Detail" required></textarea>

        <p><label for="status"><b>Status &nbsp</b></label>
        <input type="radio" name="status" value="Available" checked>Available
        <input type="radio" name="status" value="Not Available" >Not Available</p>

        <hr>
        <button type="submit" class="registerbtn">Register</button>
      </div>

</div>

<?php
    include("footer.php");
?>
       

</body>