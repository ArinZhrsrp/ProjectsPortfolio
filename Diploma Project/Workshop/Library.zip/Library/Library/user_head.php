<html>
<head>
<title>LIBRARY MANAGEMENT SYSTEM</title>
<link rel="stylesheet" type="text/css" href="library.css">
</head>

<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;background-attachment: fixed">

<center>
  <div id = "header">
      <center><a><img src = "source/library.png" width="100px" height="150px"></a></center>
    </div>

<ul>
    <li class="dropdown">
      <a href="user_home.php" class="dropbtn">HOME</a>
    </li>

    <li class="dropdown">
      <a href="user_book.php" class="dropbtn">BOOK</a>
    </li>

    <li class="dropdown">
      <a href="#user" class="dropbtn">HISTORY</a>
      <div  class = "dropdown-content">
          <a href="user_issue.php">ISSUED</a>
          <a href="user_paymentHistory.php">VIEW PAYMENT</a>
      </div>
    </li>

      <li class="dropdown">
      <a href="#admin" class="dropbtn">PAYMENT</a>
      <div  class = "dropdown-content">
          <a href="user_paymentPage.php">MAKE PAYMENT</a>
      </div>
    </li>

     <li class="dropdown">
      <a href="user_contact.php" class="dropbtn">CONTACT US</a>
    </li>

    <li class="dropdown">
      <a href="user_profile.php" class="dropbtn">PROFILE</a>
    </li>


 <li style="float:right"><a class="active" href="logout.php">LOGOUT</a></li>
</ul></center>
<br/>
</body>