<html>
<head>
<title>LIBRARY MANAGEMENT SYSTEM</title>
<link rel="stylesheet" type="text/css" href="library.css">
</head>

<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;background-attachment: fixed">

<?php
    include("user_head.php");
?>

<br/>
<div class="container">
      <center><p><h1><marquee width =60% behavior = "alternate"><font face="monotype corsiva" color="black">SELAMAT DATANG</font></h1></marquee></p>
      <h2><p>OPENING HOURS</p>
      <p>Mon - Fri : 8AM - 10PM</p>
      <p>Sat - Sun : 10AM - 3PM</p>
      <p><a href="mailto:d031810207@student.utem.edu.my"><img src = "source/mail.png" width ="50" height="50"></a></p></center>
</div>

<?php
    include("footer.php");
?>
       

</body>