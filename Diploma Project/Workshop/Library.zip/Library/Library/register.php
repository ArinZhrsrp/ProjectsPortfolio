<html>
<head>
<title>LIBRARY MANAGEMENT SYSTEM</title>
<link rel="stylesheet" type="text/css" href="library.css">
</head>

<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;background-attachment: fixed">

<?php
    include("head.php");
?>

<br/>
<div class="container">
      <form action="member_user.php" method="POST">
      <div class="container">
        <h1>Register</h1>
        <p>Please fill in this form to create an account.</p>
        <hr>

         <label for="username"><b>Username</b></label>
        <input type="text" placeholder="Enter Username" name="username" required>

        <p><label for="course"><b>Course &nbsp</b></label>
        <input type="radio" name="course" value="FTMK" checked>FTMK
        <input type="radio" name="course" value="FKE">FKE
        <input type="radio" name="course" value="FKEKK">FKEKK
        <input type="radio" name="course" value="FKM">FKM
        <input type="radio" name="course" value="FKP">FKP
        <input type="radio" name="course" value="FPTT">FPTT
        <input type="radio" name="course" value="FTKMP">FTKMP
        <input type="radio" name="course" value="FTKEE">FTKEE</p>

        <p><label for="gender"><b>Gender &nbsp</b></label>
        <input type="radio" name="gender" value="Female" checked>Female
        <input type="radio" name="gender" value="Male" >Male</p>

        <p><label for="dob"><b>Date Of Birth &nbsp</b></label>
        <input type="Date" placeholder="Enter DOB" name="dob" required></p>

        <label for="email"><b>Email</b></label>
        <input type="text" placeholder="Enter Email" name="email" required>

       
        <label for="password"><b>Password</b></label>
        <input type="password" placeholder="Enter Password" name="password" required>

        <hr>

        <p>By creating an account you agree to our Terms & Privacy</a>.</p>
        <button type="submit" class="registerbtn">Register</button>
      </div>

</div>

<?php
    include("footer.php");
?>
       

</body>