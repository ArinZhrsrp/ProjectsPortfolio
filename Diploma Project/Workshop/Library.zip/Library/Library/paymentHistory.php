<!DOCTYPE html>
<html>
<head>
<title>PAYMENT HISTORY</title>
<link rel="stylesheet" type="text/css" href="library.css">

<link href='//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css' rel='stylesheet' type='text/css'>

<!-- jQuery Library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Datatable JS -->
<script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

</head>


<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  background-attachment: fixed">

<?php
    include("admin_head.php");
?>

<!-- HTML -->
<div class="container">
    <center><p><h1>PAYMENT HISTORY</h1></p>
   <!-- Custom Filter -->
   <table>
     <tr>
       <td>
         <select id='searchByType'>
           <option value=''>-- Select Payment Type--</option>
           <option value=''>All</option>
           <option value='Late'>Late</option>
            <option value='Lost'>Lost</option>
           <option value='Broken'>Broken</option>
            <option value='Other'>Other</option>
         </select>
       </td>
       <td>
         <select id='searchByMethod'>
           <option value=''>-- Select Payment Method--</option>
           <option value=''>All</option>
           <option value='Cash'>Cash</option>
            <option value='Online Banking'>Online Banking</option>
     
         </select>
       </td>
     </tr>
   </table>

   <!-- Table -->
   <table id='empTable' class='display dataTable'>
     <thead>
       <tr>
         <th>Payment ID</th>
          <th>Username</th>
          <th>Payment Type</th>
          <th>Payment Method</th>
          <th>Date</th>
          <th>Fee</th>
          <th>Status</th>
          <th>Action</th>
          <th>Action</th>
       </tr>
     </thead>

   </table>


   <script>
     $(document).ready(function(){
  var dataTable = $('#empTable').DataTable({
    'processing': true,
    'serverSide': true,
    'serverMethod': 'post',
    //'searching': false, // Remove default Search Control
    'ajax': {
       'url':'ajaxfile2.php',
       'data': function(data){
          // Read values
          var type = $('#searchByType').val();
          var method = $('#searchByMethod').val();

          // Append to data
          data.searchByType = type;
          data.searchByMethod = method;

       }
    },
    'columns': [
       { data: 'paymentid' }, 
       { data: 'name' },
       { data: 'type' },
       { data: 'method' },
       { data: 'datepay' },
       { data: 'fee' }, 
       { data: 'status' }, 
       { data: 'action' },
       { data: 'action2' }, 
    ]
  });

  $('#searchByType').change(function(){
    dataTable.draw();
  });
  $('#searchByMethod').change(function(){
    dataTable.draw();
  });
});
   </script>

</div>

<?php
    include("footer.php");
?>


</body>
</html>
