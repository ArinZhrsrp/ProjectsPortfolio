<html>
<head>
<title>UPDATE BOOK</title>
</head>

<body>

<?php
session_start();

include("admin_head.php");
$con = mysqli_connect("localhost","root","","library");

if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}

$id = mysqli_real_escape_string($con, $_REQUEST['u_id']);
$image = mysqli_real_escape_string($con, $_POST['fileToUpload']);
$isbn = mysqli_real_escape_string($con, $_POST['u_isbn']);
$category = mysqli_real_escape_string($con, $_POST['u_category']);	
$title = mysqli_real_escape_string($con, $_POST['u_title']);
$author = mysqli_real_escape_string($con, $_POST['u_author']);
$publisher = mysqli_real_escape_string($con, $_POST['u_publisher']);
$pages = mysqli_real_escape_string($con, $_POST['u_pages']);
$detail = mysqli_real_escape_string($con, $_POST['u_detail']);
$status = mysqli_real_escape_string($con, $_POST['u_status']);

$sql = "UPDATE book SET image='".$image."',title='".$title."', author='".$author."' , publisher='".$publisher."', pages='".$pages."', detail='".$detail."', status='".$status."' where bookid = '$id'";

if (!mysqli_query($con, $sql)) {
  printf("", mysqli_affected_rows($con));


}

echo "<center>Book has been updated.</center>";
echo "<meta http-equiv=\"refresh\"content=\"3;URL=admin_book.php\">";
mysqli_close($con);
include('footer.php');
?>