<?php
include("head.php");
include ('inc/connect.php');
$username = $_POST['username'];
$course = $_POST['course'];
$gdr = $_POST['gender'];
$dob = $_POST['dob'];
$email = $_POST['email'];
$pass = $_POST['password'];

$sql = "INSERT INTO user (username, course, gender, dob, email, password) VALUES 
('$username', '$course', '$gdr', '$dob', '$email', '$pass' )" or die ("Error inserting data info table");

if($conn->query($sql) === TRUE) {
	echo"New record created succesfully";
	echo "<meta http-equiv=\"refresh\"content=\"3;URL=user_home.php\">";
} else {
	echo "Error: " . $sql . "<br>" . $conn->error;
	echo "<meta http-equiv=\"refresh\"content=\"3;URL=register.php\">";
}
 //closes specified connection
$conn->close();

?>
