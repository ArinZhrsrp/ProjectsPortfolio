<html>
<head>
<title>MAKE PAYMENT</title>
</head>

<body>

<?php
session_start();

include("admin_head.php");
$con = mysqli_connect("localhost","root","","library");

if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}

// Escape special characters, if any
$name = mysqli_real_escape_string($con, $_POST['name']);
$type = mysqli_real_escape_string($con, $_POST['type']);
$method = mysqli_real_escape_string($con, $_POST['method']);
$datepay = mysqli_real_escape_string($con, $_POST['datepay']);
$fee = mysqli_real_escape_string($con, $_POST['fee']);
$image = mysqli_real_escape_string($con, $_POST['image']);
$status = mysqli_real_escape_string($con, $_POST['status']);



$sql = "INSERT INTO payment (name, type, method, datepay, fee, image, status) VALUES ('$name', '$type', '$method', '$datepay', '$fee', '$image', '$status')";

if (!mysqli_query($con, $sql)) {
  printf("<center>$Payment Has Been Added!\n", mysqli_affected_rows($con));
  	//echo "<meta http-equiv=\"refresh\"content=\"3;URL=admin_book.php\">";

}

echo "<center>Payment has been made.</center>";
echo "<meta http-equiv=\"refresh\"content=\"3;URL=paymentHistory.php\">";
include("footer.php");
mysqli_close($con);
?>