<html>
<head>
<title>RETURN BOOK</title>
</head>

<body>

<?php
session_start();

include("user_head.php");
include('inc/connect.php');

$id = $_POST['u_id'];
$return = $_POST['u_return'];
$username = $_SESSION['username'];


$sql = "UPDATE borrow SET datereturn='".$return."' WHERE borrowid ='$id'";
$sqlLate = "UPDATE borrow SET datereturn='LATE' WHERE borrowid ='$id'";
$sqlBorrowDate = "SELECT dateborrow from borrow WHERE borrowid = '$id'";
$sql2 = "UPDATE book SET status='Available' WHERE bookid ='".$id."'";

$result = $conn->query($sqlBorrowDate);


	if($result->num_rows > 0)
	{
		$row = $result->fetch_assoc();
		 $due = date("Y-m-d", strtotime(date("Y-m-d", strtotime($row['dateborrow'])). "+ 7 day"));
	  	if($return > $due)
		{
		    if($conn->query($sqlLate) === TRUE) 
		    {
				//echo"<p style = 'text-align:center'>Please Wait...";
				//echo "<meta http-equiv=\"refresh\"content=\"3;URL=member_update.php\">";
				echo "</p>";
				if($conn->query($sql2) === TRUE) 
				{
					echo"<p style = 'text-align:center'>You have successfully return a book.";
					echo '<script>alert("YOU RETURN THE BOOK LATE!! PAY FINE!! RM2 PER DAY!!")</script>'; 
					echo '<script>window.location="user_issue.php"</script>'; 
					echo "</p>";
				} else 
				{
					echo "<p>";
					echo"<p style = 'text-align:center'>ERROR: " .$sql2. "<br>" . $conn->error;
					echo "</p>";
				}
			}
		}

		else if($return <= $due) 
		{
			if($conn->query($sql) === TRUE)
			{
				if($conn->query($sql2) === TRUE) 
				{
					echo"<p style = 'text-align:center'>You have successfully return a book.";
					echo "<meta http-equiv=\"refresh\"content=\"3;URL=user_issue.php\">";
					echo "</p>";
				} else 
				{
					echo "<p>";
					echo"<p style = 'text-align:center'>ERROR: " .$sql2. "<br>" . $conn->error;
					echo "</p>";
				}
			}
			
		}
		
		
	}

	 //closes specified connection
	$conn->close();
	include('footer.php');
	?>