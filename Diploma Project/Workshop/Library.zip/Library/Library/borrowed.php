<!DOCTYPE html>
<html>
<head>
<title>BORROW HISTORY</title>
<link rel="stylesheet" type="text/css" href="library.css">

<link href='//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css' rel='stylesheet' type='text/css'>

<!-- jQuery Library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Datatable JS -->
<script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

</head>


<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  background-attachment: fixed">

<?php
    include("admin_head.php");
?>

<!-- HTML -->
<div class="container">
    <center><p><h1>BORROW LIST</h1></p>
   
   <!-- Table -->
   <table id='empTable' class='display dataTable'>
     <thead>
       <tr>
          <th>Borrow ID</th>
          <th>Book ID</th>
          <th>Username</th>
          <th>Date Borrow</th>
          <th>Date Return</th>
           <th>Action</th>
       </tr>
     </thead>

   </table>


   <script>
     $(document).ready(function(){
  var dataTable = $('#empTable').DataTable({
    'processing': true,
    'serverSide': true,
    'serverMethod': 'post',
    //'searching': false, // Remove default Search Control
    'ajax': {
       'url':'ajaxfile7.php',
       
    },
    'columns': [
       { data: 'borrowid' },
       { data: 'bookid' },
       { data: 'username' },
       { data: 'dateborrow' },
       { data: 'datereturn' }, 
        { data: 'action' },
    ]
  });

 
  
  
});
   </script>

</div>

<?php
    include("footer.php");
?>


</body>
</html>
