<html>
<head>
<title>RETURN BOOK</title>
</head>

<body>

<?php
session_start();

include("admin_head.php");
include('inc/connect.php');

$id = $_POST['u_id'];
$return = $_POST['u_return'];

$sql = "UPDATE borrow SET datereturn='".$return."' WHERE borrowid ='$id'";

$result = $conn->query($sql);


if($conn->query($sql) === TRUE) {
	echo"<p style = 'text-align:center'>Book Has Been Return!";
	echo "<meta http-equiv=\"refresh\"content=\"3;URL=borrowed.php\">";
	echo "</p>";
} else {
	echo "<p>";
	echo"<p style = 'text-align:center'>ERROR: " .$sql. "<br>" . $conn->error;
	echo "</p>";
}

$sql2 = "UPDATE book SET status='Not Available' WHERE bookid ='$id'";

if($conn->query($sql2) === TRUE) {
	echo"<p style = 'text-align:center'>Book Status Has Been Updated.";
	echo "<meta http-equiv=\"refresh\"content=\"3;URL=borrowed.php\">";
	echo "</p>";
} else {
	echo "<p>";
	echo"<p style = 'text-align:center'>ERROR: " .$sql2. "<br>" . $conn->error;
	echo "</p>";
}

 //closes specified connection
$conn->close();
include('footer.php');
?>