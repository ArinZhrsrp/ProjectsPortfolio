<html>
<head>
<title>PROFILE</title>
<link rel="stylesheet" type="text/css" href="library.css">
</head>

<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;background-attachment: fixed">

<?php
    include("user_head.php");
?>

<br/>


<?php 
session_start();

include('inc/connect.php');

$username = $_SESSION['username'];
$password = $_SESSION['password'];

$sql = "SELECT * FROM user WHERE username = '$username' AND password = '$password'";

$result = $conn->query($sql);

if ($result->num_rows > 0) 
{
  //output data of each row
  while($row = $result->fetch_assoc())
  {
    echo "<center><h1>YOUR PROFILE</h1></center>";
    echo "<table align = 'center' border = '1' width = '50%'>";
    echo "<form method = 'post' action = 'update.php'";
    echo "<tr><th>Id: </th><td>" . $row['userid'] . "</td></tr>";
    echo "<tr><th>Username: </th><td>" . $row['username'] . "</td></tr>";
    echo "<tr><th>Course: </th><td>" . $row['course'] . "</td></tr>";
    echo "<tr><th>Gender: </th><td>" . $row['gender'] . "</td></tr>";
    echo "<tr><th>Date Of Birth: </th><td>" . $row['dob'] . "</td></tr>";
    echo "<tr><th>Email: </th><td>" . $row['email'] . "</td></tr>";
    echo "<tr><th>Password: </th><td>" . $row['password'] . "</td></tr>";
    echo "<td colspan = '2' align = 'center'><input type = 'submit' name = 'submit' value = 'UPDATE'>";
  }
  echo "</table>";
  echo "</form>";
}

else
{
  echo "0 result";
}

$conn->close();

include('footer.php');
?>
       

</body>