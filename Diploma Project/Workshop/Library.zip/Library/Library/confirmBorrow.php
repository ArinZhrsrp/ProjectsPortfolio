<html>
<head>
<title>CONFIRM ISSUE</title>
<link rel="stylesheet" type="text/css" href="library.css">
</head>

<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;background-attachment: fixed">

<br/>
<!-- <div id = "content">
      <p><h1><marquee width =60% behavior = "alternate"><font face="monotype corsiva" color="black">SELAMAT DATANG</font></h1></marquee></p>
</div> -->

<?php 
session_start();

include("user_head.php");
include('inc/connect.php');

$id = $_REQUEST['id'];
$username = $_SESSION['username'];
$password = $_SESSION['password'];

$sql = "SELECT * FROM book where bookid = $id";

$result = $conn->query($sql);

if ($result->num_rows > 0) 
{
	echo "<div class='container'>";
	echo "<center><h1>CONFIRM ISSUE</h1></center>";
	echo "<table align = 'center' border = '1' width = '50%' color='white'>";
	echo "<form action = 'member_borrow.php' method = 'post' enctype='multipart/form-data'>";

	//output data of each row
	while($row = $result->fetch_assoc())
	{
		echo "<tr><th>Book ID: </th><td><input type='text' name='u_id' readonly value='".$row['bookid']."' required></td></tr>";
		?>
		<tr><th>Book Image: </th><td align="center"><img class="pic" src="bookimage/<?php echo $row['image'] ?>" width='350' height='600'/></td></tr>
		<?php
		echo "<tr><th>ISBN: </th><td><input type='text' name='u_isbn' readonly value='".$row['isbn']."' required></td></tr>";
		echo "<tr><th>Category: </th><td><input type='text' name='u_category' readonly value='".$row['category']."' required></td></tr>";
		echo "<tr><th>Title: </th><td><center><input type = 'text' name = 'u_title' readonly value = '" .$row['title']."'> </td></tr>";
		echo "<tr><th>Author: </th><td><center><input type = 'text' name = 'u_author' readonly value = '" .$row['author']."'> </td></tr>";
		echo "<tr><th>Publisher: </th><td><center><input type = 'text' name = 'u_publisher' readonly value = '" .$row['publisher']."'> </td></tr>";
		echo "<tr><th>Pages: </th><td><center><input type = 'text' name = 'u_pages' readonly value = '" .$row['pages']."'> </td></tr>";
		echo "<tr><th>Detail: </th><td><center><input type = 'text' name = 'u_detail' readonly value = '" .$row['detail']."'/> </td></tr>";
		echo "<tr><th>Return Date: </th><td><center><input type = 'text' name = 'u_return' readonly value = ' NOT YET RETURN'> </td></tr>";

		$statusValue = $row['status'];

		if($statusValue == 'Available')
		{
			echo "<tr><th>Status: </th><td><center><input type = 'text' name = 'u_status' readonly value = '" .$row['status']."'> </td></tr>";
			echo "<tr><td colspan ='2'><input type ='submit' id='btnSubmit' class='registerbtn' name = 'submit' value ='BORROW'></td></tr>";

			echo "</tr>";
		}
		else
		{
			echo '<script>alert("BOOK IS BEING BORROWED BY OTHERS. PLEASE TRY AGAIN OR CHOOSE ANOTHER BOOK.")</script>'; 
			echo '<script>window.location="user_book.php"</script>';  
			echo "</tr>";	
		}

		
	}
	echo "</table>";
}

else
{
	echo "0 result";
}

$conn->close();

include('footer.php');
?>
</div>

<script>
    function manage(btnAvailable) {
        var bt = document.getElementById('btnSubmit');
        if (btnAvailable.value != 'Available') {
            bt.disabled = false;
        }
        else {
            bt.disabled = true;
        }
    }    
</script>
</body>
