<!DOCTYPE html>
<html>
<head>
<title>BOOK</title>
<link rel="stylesheet" type="text/css" href="library.css">

<link href='//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css' rel='stylesheet' type='text/css'>

<!-- jQuery Library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Datatable JS -->
<script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

<style>
  .card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  width: 200px;
  margin-left: 11%;
  text-align: center;
  font-family: arial;
  float : left;
  display: block;
  position: relative;
  height: 550px;
  }

.category {
  color: grey;
  font-size: 20px;
  
}

.author {
  color: grey;
  
}

.title
{
    font-family: "Comic Sans MS", cursive, sans-serif;
    font-size: 18px;
    height: 48px;
    line-height: 20px;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    padding-bottom: 10px;
    border: 1px solid #000000;
    border-color: transparent;
    padding-top: 5px;
    overflow: hidden;
    text-overflow: ellipsis;
    margin-left: 10%;
    margin-right: 10%;
}

.description
{
    margin-left: 10%;
    margin-right: 10%;
    height: 100px;
    line-height: 18px;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 4;
    overflow: hidden;
    margin-bottom: 20px;
    font-family: Roboto-Regular,'Helvetica Neue',Helvetica,Tahoma,Arial,'Sans-serif';
    font-size: 14px;
}

.card button {
  border: none;
  outline: 0;
  padding: 12px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

.card button:hover {
  opacity: 0.7;
}

.ref {
   color: white;
}

</style>
</head>


<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  background-attachment: fixed">

<?php 
session_start();

include('head.php');
include('inc/connect.php');

$sql = "SELECT * from book";

$result = $conn->query($sql);

if ($result->num_rows > 0) 
{
  //output data of each row
  while($row = $result->fetch_assoc())
  {
  ?>
  <div class="card">
  <center><img class="pic" src="bookimage/<?php echo $row['image'] ?>" width = '100%'/></center>
  <div class="title">
  <h3><?php echo $row['title'] ?></h3></div>
  <div class="description">
  <p class="author"><?php echo $row['author'] ?></p>
  <p class="category"><?php echo $row["category"]; ?></p>
  </div>
  <p><button><a class="ref" href="viewBook.php">View</a></button></p>
  </div>

  <?php 
  }
  
  $conn->close();

include('footer.php');

}

else
{
 
  $conn->close();

include('footer.php');
}


?>
</html>
