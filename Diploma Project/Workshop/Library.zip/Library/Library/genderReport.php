<html>
<title>GENDER REPORT</title>

<?php
include("admin_head.php");
$conn = mysqli_connect("localhost","root", "","library");

$query = "SELECT gender,count(*) as number from user GROUP BY gender";
$result = mysqli_query($conn,$query);

?>
<!DOCTYPE html>
<html align ="center">
<head>
  <title>Report User Record</title>

  <html>
  <head >
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript" >
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['gender', 'Number'],
          <?php

          while($chart = mysqli_fetch_array($result))
          {
            echo "['".$chart["gender"]."',".$chart["number"]."],";
          }

          ?>
        ]);

        var options = {
          title: 'Percentage of Male and Female Staff',
          pieHole: 0.4
         
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <h3 align="center"> USER GENDER REPORT </h3>
    <div align="center" id="piechart" style="width: '100%'; height: 500px;"></div>

    
  </body>
</html>
</head>
</html>
<?php
include("footer.php");
?>

</html>