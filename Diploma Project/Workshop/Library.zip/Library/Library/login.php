<html>
<head>
<title>LIBRARY MANAGEMENT SYSTEM</title>
<link rel="stylesheet" type="text/css" href="library.css">
</head>

<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;background-attachment: fixed">

<?php
 session_start();
 
   
if (!isset($_SESSION['username']))
{
  $_SESSION['username'] = $_POST['username'];
  $_SESSION['password'] = $_POST['password'];
}

include ('inc/connect.php');

$sql = "SELECT * FROM user WHERE username ='" . $_SESSION['username']."'AND password='".$_SESSION['password']."'";
$result = $conn->query($sql);

if($result->num_rows == 0)
{
  session_unset();
  echo '<script>alert("Login Fail.Try Again")</script>'; 
  echo '<script>window.location="home.php"</script>';  
}
else if($_SESSION['username']=='shiwwinzahra')
{
  echo '<script>alert("Login Success!)</script>'; 
  echo '<script>window.location="admin_home.php"</script>'; 
}
else
{
	include('user_home.php');
}

$conn->close();
?>     

</body>