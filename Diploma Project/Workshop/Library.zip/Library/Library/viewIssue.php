<!DOCTYPE html>
<html>
<head>
<title>VIEW ISSUE</title>
<link rel="stylesheet" type="text/css" href="library.css">

<link href='//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css' rel='stylesheet' type='text/css'>

<!-- jQuery Library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Datatable JS -->
<script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

</head>


<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  background-attachment: fixed">

<?php
    include("admin_head.php");
?>

<!-- HTML -->
<div class="container">
    <center><p><h1>ISSUE LIST</h1></p>
   <!-- Custom Filter -->
   <table>
     <tr>
       <td>
         <select id='searchByStatus'>
           <option value=''>-- Select Status--</option>
           <option value=''>All</option>
           <option value='Complete'>Complete</option>
           <option value='Incomplete'>Incomplete</option>
          </select>
       </td>
       <td>
         <select id='searchByOption'>
           <option value=''>-- Select Option--</option>
           <option value=''>All</option>
           <option value='Request'>Request</option>
           <option value='Other'>Other</option>
          </select>
       </td>
     </tr>
   </table>

   <!-- Table -->
   <table id='empTable' class='display dataTable'>
     <thead>
       <tr>
         <th>Issue ID</th>
         <th>Name</th>
        <th>Title</th>
        <th>Option</th>
        <th>Contact/Email</th>
        <th>Message</th>
        <th>Status</th>
        <th>Action</th>

       </tr>
     </thead>

   </table>


   <script>
     $(document).ready(function(){
  var dataTable = $('#empTable').DataTable({
    'processing': true,
    'serverSide': true,
    'serverMethod': 'post',
    //'searching': false, // Remove default Search Control
    'ajax': {
       'url':'ajaxfile5.php',
       'data': function(data){
          // Read values
          var status = $('#searchByStatus').val();
          var purpose = $('#searchByOption').val();

          // Append to data
          data.searchByStatus = status;
          data.searchByOption = purpose;

       }
    },
    'columns': [
       { data: 'contactid' }, 
       { data: 'name' },
       { data: 'title' },
       { data: 'purpose' },
       { data: 'email' },
       { data: 'message' }, 
       { data: 'status' },
       { data: 'action' }, 
    ]
  });

  $('#searchByStatus').change(function(){
    dataTable.draw();
  });
  $('#searchByOption').change(function(){
  dataTable.draw();
  });
});
   </script>

</div>

<?php
    include("footer.php");
?>


</body>
</html>
