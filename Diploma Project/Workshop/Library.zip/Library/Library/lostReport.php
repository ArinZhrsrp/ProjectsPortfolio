<?php
//session_start();
include("admin_head.php");
include ('inc/connect.php');
?>

<script>
	function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['type'],
         <?php
         $sql = "SELECT type, Count(type) FROM payment";
         $fire = mysqli_query($conn,$sql);
          while ($result = mysqli_fetch_assoc($fire)) {
            echo"['".$result['type']."',".$result['Count(type)']."],";
          }

         ?>
        ]);

        var options = {
          title: 'Payment type with their quantity'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
</script>