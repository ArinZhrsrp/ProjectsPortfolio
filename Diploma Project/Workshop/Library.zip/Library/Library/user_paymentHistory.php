<!DOCTYPE html>
<html>
<head>
<title>ISSUE HISTORY</title>
<link rel="stylesheet" type="text/css" href="library.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>


<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
  background-color: white;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

</style>
</head>


<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;background-attachment: fixed">

<?php
    include("user_head.php");
    include('inc/connect.php'); 
?>



<table>

<input id="myInput" type="text" placeholder="Search..">
<br><br>

  <thead>
  <tr>
          <th>ID</th>
          <th>Payment Type</th>
          <th>Payment Method</th>
          <th>Datepay</th>
          <th>Fee</th>
          <th>Status</th>

  </tr>
  </thead>

  <tbody id="myTable">

<?php 
session_start();

include('inc/connect.php');

$username = $_SESSION['username'];
$password = $_SESSION['password'];

$sql = "SELECT * FROM payment WHERE name = '$username'";

$result = $conn->query($sql);

if ($result->num_rows > 0) 
{
  //output data of each row
  while($row = $result->fetch_assoc())
  {
  ?>
  <tr class="<?php if(isset($username)) echo $username;?>">
  <td><?php echo $row["paymentid"]; ?></td>
  <td><?php echo $row["type"]; ?></td>
  <td><?php echo $row["method"]; ?></td>
  <td><?php echo $row["datepay"]; ?></td>
  <td><?php echo $row["fee"]; ?></td>
  <td><?php echo $row["status"]; ?></td>
  
 <?php 
  }
  echo "</tr></tbody></table>";
  $conn->close();

include('footer.php');

}

else
{
  echo "<td colspan = 5><center>No data available in table</center></td>";
  echo "</tr></tbody></table>";
  $conn->close();

include('footer.php');
}


?>
</body>
</html>
