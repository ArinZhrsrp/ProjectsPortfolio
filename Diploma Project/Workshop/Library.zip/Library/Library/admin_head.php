<html>
<head>
<title>LIBRARY MANAGEMENT SYSTEM</title>
<link rel="stylesheet" type="text/css" href="library.css">
</head>

<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  background-attachment: fixed">

<center>
  <div id = "header">
      <center><a><img src = "source/library.png" width="100px" height="150px"></a></center>
    </div>

<ul>
    <li class="dropdown">
      <a href="admin_home.php" class="dropbtn">HOME</a>
    </li>

    <li class="dropdown">
      <a href="#" class="dropbtn">BOOK</a>
       <div  class = "dropdown-content">
          <a href="admin_book.php">ADD/DELETE/UPDATE</a>
          <a href="borrowed.php">BORROW HISTORY</a>
    </li>

    <li class="dropdown">
      <a href="user.php" class="dropbtn">USER LIST</a>
    </li>

    <li class="dropdown">
      <a href="admin_profile.php" class="dropbtn">VIEW PROFILE</a>
    </li>

    <li class="dropdown">
      <a href="#admin" class="dropbtn">PAYMENT</a>
      <div  class = "dropdown-content">
          <a href="paymentPage.php">MAKE PAYMENT</a>
          <a href="paymentHistory.php">PAYMENT HISTORY</a>
      </div>
    </li>

  <li class="dropdown">
      <a href="viewIssue.php" class="dropbtn">ISSUES</a>
    </li>

    <li class="dropdown">
      <a href="#" class="dropbtn">REPORT</a>
       <div  class = "dropdown-content">
          <a href="genderReport.php">GENDER REPORT</a>
          <a href="overdueReport.php">OVER DUE REPORT</a>
          <a href="paymentReasonReport.php">PAYMENT REASON REPORT REPORT</a>
          <a href="selectMonth.php">PAYMENT FEES REPORT</a>
          <a href="contactReport.php">CONTACT REPORT</a>
    </li>

  


 <li style="float:right"><a class="active" href="logout.php">LOGOUT</a></li>
</ul></center>
<br/>
</body>