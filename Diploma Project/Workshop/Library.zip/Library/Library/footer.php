<html>
<head>
<title>Footer Page</title>
</head>

<style>
#footer
{  
	bottom:0;
	padding: 20px;
	height: 2%;
	color:black; 
	font-family:arial;
	float: left;
	margin-top: 5%;
	width: 100%;

}
</style>

<body>
	<div id = "footer">
            <p>2020 WORKSHOP PROJECT BY SHIRIN ZAHRA</font></p>
          </div>
</body>
</html>