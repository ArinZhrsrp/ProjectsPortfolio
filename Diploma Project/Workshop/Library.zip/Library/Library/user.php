<!DOCTYPE html>
<html>
<head>
<title>MEMBER</title>
<link rel="stylesheet" type="text/css" href="library.css">

<link href='//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css' rel='stylesheet' type='text/css'>

<!-- jQuery Library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Datatable JS -->
<script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

</head>


<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  background-attachment: fixed">

<?php
    include("admin_head.php");
?>

<!-- HTML -->
<div class="container">
<center><p><h1>LIST MEMBER</h1></p><p><h2><a class="active" href = "register_User.php">ADD NEW USER</a></h2></p>

   <table>
     <tr>
       <td>
         <select id='searchByCourse'>
           <option value=''>-- Select Course--</option>
           <option value=''>All</option>
           <option value='FTMK'>FTMK</option>
            <option value='FKE'>FKE</option>
            <option value='FKEKK'>FKEKK</option>
           <option value='FKM'>FKM</option>
            <option value='FKP'>FKP</option>
            <option value='FPTT'>FPTT</option>
           <option value='FTKMP'>FTKMP</option>
            <option value='FTKEE'>FTKEE</option>
         </select>
       </td>
        <td>
         <select id='searchByGender'>
           <option value=''>-- Select Gender--</option>
           <option value=''>All</option>
           <option value='Male'>Male</option>
            <option value='Female'>Female</option>
         </select>
       </td>
     </tr>
   </table>

   <!-- Table -->
   <table id='empTable' class='display dataTable'>
     <thead>
       <tr>
          <th>User ID</th>
          <th>Username</th>
          <th>Course</th>
          <th>Gender</th>
          <th>Date Of Birth</th>
          <th>Email</th>
          <th>Password</th>
          <th>Action</th>
       </tr>
     </thead>

   </table>


   <script>
     $(document).ready(function(){
  var dataTable = $('#empTable').DataTable({
    'processing': true,
    'serverSide': true,
    'serverMethod': 'post',
    //'searching': false, // Remove default Search Control
    'ajax': {
       'url':'ajaxfile4.php',
       'data': function(data){
          // Read values
          var gender = $('#searchByGender').val();
          var course = $('#searchByCourse').val();

          // Append to data
          data.searchByGender = gender;
          data.searchByCourse = course;

       }
    },
    'columns': [
       { data: 'userid' }, 
       { data: 'username' },
       { data: 'course' },
       { data: 'gender' },
       { data: 'dob' },
       { data: 'email' },
       { data: 'password' },
       { data: 'action' },
    ]
  });

  $('#searchByGender').change(function(){
    dataTable.draw();
  });

  $('#searchByCourse').change(function(){
    dataTable.draw();
  });
});
   </script>

</div>

<?php
    include("footer.php");
?>


</body>
</html>
