<html>
<head>
<title>CONTACT US</title>
<link rel="stylesheet" type="text/css" href="library.css">
</head>

<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;background-attachment: fixed">

<?php
    include("head.php");
?>

<div class="container">

      <form action="member_contact.php" method="post">
      <div class="container">
        <h1>Contact Us</h1>
        <p>To reserve or request book, just send us a message:</p>
        <hr>

        <input type="text" placeholder="Enter Name" name="name" required>

        <input type="text" placeholder="Enter Title" name="title" required>

        <p><label for="purpose"><b>Option &nbsp</b></label>
        <input type="radio" name="purpose" value="Request Book" checked>Request Book &nbsp
        <input type="radio" name="purpose" value="Other">Other &nbsp</p>

         <input type="text" placeholder="Enter Contact Number / Email" name="email" required>
        <input type="text" placeholder="Message \ Special requirements" name="message" required>
        
        <p><label for="status"><b>Status &nbsp</b></label>
        <input type="radio" name="status" value="Incomplete" checked>Incomplete &nbsp
        </p>
        
        <hr>
        <button type="submit" class="registerbtn">SEND MESSAGE</button>
      </div>

</div>

<?php
    include("footer.php");
?>
       

</body>