<!DOCTYPE html>
<html>
<title>CONTACT REPORT</title>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 70%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>

<?php
  $url='localhost';
  $username='root';
  $password='';
  $conn=mysqli_connect($url,$username,$password,"library");
  if(!$conn){
  die('Could not Connect My Sql:' .mysql_error());

  }

$result = mysqli_query($conn,"select month(contactdate) as month, count(contactid) as total_amount
from contact
group by month(contactdate)");

include("admin_head.php");
include('inc/connect.php'); 
?>

<div class="container">
<center><h2>CONTACT REPORT</h2></center>

<center><table>
  <tr>
    <th>Month</th>
    <th>Amount</th>  
  </tr>

<?php
  $i=0;
  while($row = mysqli_fetch_array($result)) {
 $monthNum  = $row["month"];
  $dateObj   = DateTime::createFromFormat('!m', $monthNum);
  $monthName = $dateObj->format('F');
?>
  <tr>
    <td><?php echo $monthName; ?></td>
    <td><?php echo $row["total_amount"]; ?></td>
  </tr>

<?php
$i++;
}
?> 
</table></center></div>

<?php
include('footer.php');
?>

</body>
</html>