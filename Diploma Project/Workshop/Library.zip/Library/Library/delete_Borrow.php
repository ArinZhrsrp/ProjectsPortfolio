<html>
<head>
<title>DELETE BOOK</title>
<link rel="stylesheet" type="text/css" href="library.css">
</head>

<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;background-attachment: fixed">

<?php
session_start();

include('admin_head.php');
include('inc/connect.php');

$id=$_REQUEST['id'];

$sql = "DELETE FROM borrow WHERE borrowid='".$id."'";
$result = $conn->query($sql);

if($conn->query($sql)===TRUE)
{
  echo "<p style='text-align:center'>Data $id Had Been Deleted!";
  echo "<p>";
}
else
{
  echo "<p>";
  echo "<p style='text-align:center'>Error: ".$sql."<br>".$conn->error;
  echo "<p>";
}
  echo "<meta http-equiv=\"refresh\" content=\"2;URL=borrowed.php\">";

$conn->close();
?>

<?php
    include("footer.php");
?>
       

</body>