<?php
include 'config.php';

## Read value
$draw = $_POST['draw'];
$row = $_POST['start'];
$rowperpage = $_POST['length']; // Rows display per page
$columnIndex = $_POST['order'][0]['column']; // Column index
$columnName = $_POST['columns'][$columnIndex]['data']; // Column name
$columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
$searchValue = $_POST['search']['value']; // Search value

## Custom Field value
$searchByCategory = $_POST['searchByCategory'];
$searchByStatus = $_POST['searchByStatus'];

## Search 
$searchQuery = " ";
if($searchByCategory != ''){
   $searchQuery .= " and (category='".$searchByCategory."') ";
}
if($searchByStatus != ''){
   $searchQuery .= " and (status='".$searchByStatus."') ";
}
if($searchValue != ''){
   $searchQuery .= " and (isbn like '%".$searchValue."%' or title like '%".$searchValue."%' or author like '%".$searchValue."%' or publisher like '%".$searchValue."%') ";
}

## Total number of records without filtering
$sel = mysqli_query($con,"select count(*) as allcount from book");
$records = mysqli_fetch_assoc($sel);
$totalRecords = $records['allcount'];

## Total number of records with filtering
$sel = mysqli_query($con,"select count(*) as allcount from book WHERE 1 ".$searchQuery);
$records = mysqli_fetch_assoc($sel);
$totalRecordwithFilter = $records['allcount'];

## Fetch records
$empQuery = "select * from book WHERE 1 ".$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$row.",".$rowperpage;
$empRecords = mysqli_query($con, $empQuery);
$data = array();

while ($row = mysqli_fetch_assoc($empRecords)) {
   $data[] = array(
    "bookid"=>$row['bookid'],
     "isbn"=>$row['isbn'],
     "category"=>$row['category'],
     "title"=>$row['title'],
     "author"=>$row['author'],
     "publisher"=>$row['publisher'],
     "pages"=>$row['pages'],
     "detail"=>$row['detail'],
     "status"=>$row['status'],
     "action"=>'<a href="confirmBorrow.php?id='.$row['bookid'].'">Borrow</a>',
   );
}

## Response
$response = array(
  "draw" => intval($draw),
  "iTotalRecords" => $totalRecords,
  "iTotalDisplayRecords" => $totalRecordwithFilter,
  "aaData" => $data
);

echo json_encode($response);