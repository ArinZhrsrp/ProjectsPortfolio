<html>
<head>
<title>BACKGROUND</title>
<link rel="stylesheet" type="text/css" href="library.css">
</head>

<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  background-attachment: fixed">

<?php
 
    include("head.php");
?>

<br/>
<div class = "container">

      <center><p><h1>BACKGROUND</h1></p>
      <p>Universiti Teknikal Malaysia Melaka (UTeM) was established as a result of the re-branding of Kolej Universiti Teknikal Kebangsaan Malaysia (KUTKM) Section 8 of the University and College University Act 1971 (Act 30) under the Universiti Teknikal Malaysia Melaka Enactment (Pemerbadanan 2007), which was gazetted as P.U. (A) 45/2007 on 1 February 2007. The UTeM Library has been in operation since 10 June 2001, serving 348 pioneer students at the Temporary Campus in Taman Tasik Utama, Ayer Keroh, Melaka.</p>

      <p><img src = "source/2001.jpg" height="50%"><img src = "source/2001(2).jpg" height="50%"></p><p>Our Library in 2001</p><br/>

      <p>On 5 September 2005, Laman Hikmah Library was relocated from the Temporary Campus to the Industrial Campus, which began its operation on 12 September 2005. With an area of 2,229 square meters, Laman Hikmah Library could accommodate approximately 400 users. Moreover, the Main Laman Hikmah Library (432 square meters), provides a seating capacity of 120 users which caters to the needs of students from both the Faculty of Electrical Engineering (FKE) and the Faculty of Electronics and Computer Engineering (FKEKK).</p>

      <p><img src = "source/2008.jpg" height="50%"><img src = "source/2008(2).jpg" height="50%"></p><p>FKEKK Library in 2008</p><br/>

      <p>Laman Hikmah Library has also opened a branch in the City Campus, Jalan Hang Tuah, Melaka, on 1 October 2007, to provide reference facilities for the post graduate students at the Institute of Technology Management and Entrepreneurship (IPTK) as well as the University. On 8 July 2009, Laman Hikmah Library moved its location from the Industrial Campus to a new building at the Main Campus, Durian Tunggal. It started its operation on 29 September 2009. It was closed on 16 January 2019 and merged with Technology Campus library.</p>

      <p><img src = "source/2018.jpg" height="50%"></p><p>City Campus Library in 2018</p><br/>

      <p>Laman Hikmah Library at the Main Campus (10,063.68 square meters) provides a seating capacity of 500 users at any one time. The Industrial Campus Library was closed on 3 September 2009. On 21 April 2011, Laman Hikmah Library opened a branch at the Industrial Campus, Hang Tuah Jaya, Melaka to provide reference facilities for the students from both the Faculty of Mechanical (FKM) and Faculty of Technology Engineering (FTK). With an area of 2,229 square meters, Laman Hikmah Library can accommodate approximately 400 users.</p>

      <p><img src = "source/techcamp.jpg" height="50%"></p><p>Technology Campus Library</p><br/>

      <p>Laman Hikmah Library has a total collection of more than 115,000 titles including 13 subscribed database titles which includes engineering materials related to the core areas of Electrical Engineering, Electronics and Computer Engineering, Mechanical Engineering, Manufacturing Engineering , Engineering Technology, Information & Communication Technology and Technology Management &Technopreneurship. In addition, there are also collections of other scientific fields such as Physics, Chemistry and Mathematics, as well as general readings.</p>

      <p><img src = "source/concept.jpg" height="50%"></p><p>Library Main Campus Concept</p><br/>

      <p>In order to suit with user needs, library provides services such as Online Renewal, Inter Library Loan, User Education Programme, Library Exhibition, User Advisory Desk, Order n Collect and many more. To support research activities, we also provide Information Packaging and Research Appointment services in line to serve the University. Other than services, we have many facilities such as discussion rooms, viewing rooms, carrel rooms, iPad, hoverboard and etc. We also offer room and area for rental to University and public.</p>

      <p><img src = "source/now.jpg" height="50%"></p><p>Main Campus Library</p><br/>

      <p>We also concerned with Millennials and Y Generations by our new concept which are more leisure, interactive and conducive for user to optimal use of the library as a meeting place and as a second home. In future, Laman Hikmah Library will become a pioneer among academic Library which open 24 hours to user at Level 1.</p></center>


</div>

<?php
    include("footer.php");
?>
       

</body>