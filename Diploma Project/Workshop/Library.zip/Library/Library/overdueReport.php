<html>
<title>OVERDUE REPORT</title>


<?php
//session_start();
include("admin_head.php");
include ('inc/connect.php');


$sql = "SELECT name, COUNT(paymentid) as Total,sum(fee) as Sum FROM payment WHERE type = 'Late' GROUP BY name ORDER BY Total DESC";
  

$result = $conn->query($sql);

if ($result-> num_rows > 0)  
{
  echo "<center><h3>O V E R D U E &nbsp; L I S T </h3></center>";
  echo "<table align='center' border='1' width='70%'>";
  echo "<tr>
      <th>Username</th>
      <th>Total</th>
      <th>Sum Fees</th>
      
    </tr>";
  
  while ($row=$result->fetch_assoc()) 
  {
    echo "<tr>";
    echo "<td><center>" . $row['name'] . "</center></td>";
    echo "<td><center>" . $row['Total'] . "</center></td>";
    echo "<td><center>" . $row['Sum'] . "</center></td>";
    
  }
  echo "</table>";
} 
else {
  echo "0 results";
}

include ('footer.php');
$conn->close();

?>
</html>