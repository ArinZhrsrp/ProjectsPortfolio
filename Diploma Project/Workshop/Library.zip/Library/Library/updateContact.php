<html>
<head>
<title>UPDATE USER</title>
<link rel="stylesheet" type="text/css" href="library.css">
</head>

<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;background-attachment: fixed">

<br/>
<!-- <div id = "content">
      <p><h1><marquee width =60% behavior = "alternate"><font face="monotype corsiva" color="black">SELAMAT DATANG</font></h1></marquee></p>
</div> -->

<?php 
session_start();

include("admin_head.php");
include('inc/connect.php');

$id = $_REQUEST['id'];
$username = $_SESSION['username'];
$password = $_SESSION['password'];

$sql = "SELECT * FROM contact where contactid = $id";


$result = $conn->query($sql);

if ($result->num_rows > 0) 
{
	//output data of each row
	while($row = $result->fetch_assoc())
	{
		echo "<center><h1>ISSUE</h1></center>";
		echo "<table align = 'center' border = '1' width = '80%'>";
		echo "<form action = 'updateFinalContact.php' method = 'post'>";
		echo "<tr><th>Issue Id: </th><td><input type='text' name='u_id' readonly value='".$row['contactid']."' required></td></tr>";
		echo "<tr><th>Name: </th><td>" . $row['name'] . "</td></tr>";
		echo "<tr><th>Title: </th><td>" . $row['title'] . "</td></tr>";
		echo "<tr><th>Option: </th><td>" . $row['purpose'] . "</td></tr>";
		echo "<tr><th>Contact/Email: </th><td>" . $row['email'] . "</td></tr>";
		echo "<tr><th>Message: </th><td>" . $row['message'] . "</td></tr>";

		$statusValue = $row['status'];

		if($statusValue == 'Complete')
		{
			echo "<tr><th>Status: </th><td><input type = 'radio' name = 'u_status' value = 'Complete' checked>Complete";
			echo "<input type = 'radio' name = 'u_status' value = 'Incomplete'>Incomplete</td>";
		}
		else
		{
			echo "<tr><th>Status: </th><td><input type = 'radio' name = 'u_status' value = 'Incomplete' checked>Incomplete";
			echo "<input type = 'radio' name = 'u_status' value = 'Complete'>Complete</td>";
		}


	
		echo "<tr><td colspan ='2'><input type ='submit' name = 'submit' value ='UPDATE'>
									<input type ='reset' name = 'reset' value ='CLEAR'></td></tr>";

		echo "</tr>";
	}
	echo "</table>";
}

else
{
	echo "0 result";
}

$conn->close();

include('footer.php');
?>

</body>