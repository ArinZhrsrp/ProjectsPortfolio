<?php
echo '<script>alert("LOGIN TO SEE DESCRIPTION!!")</script>'; 
			echo '<script>window.location="book.php"</script>'; 
			?>