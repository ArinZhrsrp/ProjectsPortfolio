<html>
<title>PAYMENT REASON REPORT</title>


<?php
include("admin_head.php");
$conn = mysqli_connect("localhost","root", "","library");

$query = "SELECT type,count(*) as number from payment GROUP BY type";
$result = mysqli_query($conn,$query);

?>
<!DOCTYPE html>
<html align ="center">
<head>
  <title>Report User Record</title>

  <html>
  <head >
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript" >
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['type', 'Number'],
          <?php

          while($chart = mysqli_fetch_array($result))
          {
            echo "['".$chart["type"]."',".$chart["number"]."],";
          }

          ?>
        ]);

        var options = {
          title: 'Percentage of Why User Make Payment',
          pieHole: 0.4
         
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <h3 align="center"> Payment Reason Report </h3>
    <div align="center" id="piechart" style="width: '100%'; height: 500px;"></div>

    
  </body>
</html>

</head>
<body>

</body>
</html>

<?php
include("footer.php");
?>
</html>