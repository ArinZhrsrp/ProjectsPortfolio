<html>
<head>
<title>UPDATING BOOK</title>
</head>

<body>

<?php
session_start();

include("user_head.php");
include('inc/connect.php');

$id = $_REQUEST['id'];

$sql = "UPDATE book SET status='Not Available' WHERE bookid ='$id'";

if($conn->query($sql) === TRUE) {
	echo"<p style = 'text-align:center'>You have successfully borrow a book.";
	// echo "<meta http-equiv=\"refresh\"content=\"3;URL=user_book.php\">";
	echo "</p>";
} else {
	echo "<p>";
	echo"<p style = 'text-align:center'>ERROR: " .$sql. "<br>" . $conn->error;
	echo "</p>";
}
 //closes specified connection
$conn->close();
include('footer.php');
?>