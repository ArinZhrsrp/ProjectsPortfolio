<html>
<head>
<title>UPDATE PAYMENT</title>
</head>

<body>

<?php
session_start();

include("admin_head.php");
include('inc/connect.php');

$id = $_POST['u_id'];
$status = $_POST['u_status'];


$sql2 = "UPDATE payment SET status='Complete' WHERE paymentid ='$id'";

if($conn->query($sql2) === TRUE) {
	echo"<p style = 'text-align:center'>Payment Status Has Been Updated.";
	echo "<meta http-equiv=\"refresh\"content=\"3;URL=paymentHistory.php\">";
	echo "</p>";
} else {
	echo "<p>";
	echo"<p style = 'text-align:center'>ERROR: " .$sql2. "<br>" . $conn->error;
	echo "</p>";
}

 //closes specified connection
$conn->close();
include('footer.php');
?>