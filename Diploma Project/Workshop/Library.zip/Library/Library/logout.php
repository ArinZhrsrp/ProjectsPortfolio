<?php
session_start();
if(isset($_SESSION['username']))
{
	$_SESSION = array();
	session_destroy();
	echo '<script>alert("Loging Out!);</script>'; 
	echo "<meta http-equiv=\"refresh\" content=\"3;URL=home.php\">";
}
?>