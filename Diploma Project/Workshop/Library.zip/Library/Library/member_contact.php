<html>
<head>
<title>CONTACT US</title>
</head>

<body>

<?php
session_start();

include("head.php");
include('inc/connect.php');

$name = $_POST['name'];
$title = $_POST['title'];
$purpose = $_POST['purpose'];
$email = $_POST['email'];
$message = $_POST['message'];
$status = $_POST['status'];

$sql = "INSERT INTO contact (name, title, purpose, email, message, status) VALUES ('$name', '$title', '$purpose', '$email', '$message', '$status' )" or die ("Error inserting data info table");

if($conn->query($sql) === TRUE) {
	echo"<p style = 'text-align:center'>Your Issue Has Been Submitted!";
	echo "</p>";
} else {
	echo "<p>";
	echo"<p style = 'text-align:center'>Error sending issue!! " .$sql. "<br>" . $conn->error;
	echo "</p>";
}
 //closes specified connection
$conn->close();
include('footer.php');
?>