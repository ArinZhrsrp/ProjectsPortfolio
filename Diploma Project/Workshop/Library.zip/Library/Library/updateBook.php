<html>
<head>
<title>UPDATE BOOK</title>
<link rel="stylesheet" type="text/css" href="library.css">
</head>

<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;background-attachment: fixed">

<br/>
<!-- <div id = "content">
      <p><h1><marquee width =60% behavior = "alternate"><font face="monotype corsiva" color="black">SELAMAT DATANG</font></h1></marquee></p>
</div> -->

<?php 
session_start();

include("admin_head.php");
include('inc/connect.php');

$id = $_REQUEST['id'];
$username = $_SESSION['username'];
$password = $_SESSION['password'];

$sql = "SELECT * FROM book where bookid = $id";

$result = $conn->query($sql);

if ($result->num_rows > 0) 
{
	//output data of each row
	while($row = $result->fetch_assoc())
	{
		echo "<div class = 'container'> ";
		echo "<center><h1>UPDATE BOOK</h1></center>";
		echo "<table align = 'center' border = '1' width = '50%' color='white'>";
		echo "<form action = 'updateFinalBook.php' method = 'post'>";
		echo "<tr><th>Id: </th><td><input type='text' name='u_id' value='".$row['bookid']."' required></td></tr>";
		?>
		<tr><th>Book Image: </th><td align="center"><img class="pic" src="bookimage/<?php echo $row['image'] ?>" width='350' height='600'/></td></tr>
		<tr><th>New Image</th><td align="center"><input type='file' name='fileToUpload' required></td></tr>
		<?php
		echo "<tr><th>ISBN: </th><td><input type='text' name='u_isbn' readonly value='".$row['isbn']."' required></td></tr>";
		echo "<tr><th>Category: </th><td><input type='text' name='u_category'  value='".$row['category']."' required></td></tr>";
		echo "<tr><th>Title: </th><td><center><input type = 'text' name = 'u_title' value = '" .$row['title']."'> </td></tr>";
		echo "<tr><th>Author: </th><td><center><input type = 'text' name = 'u_author' value = '" .$row['author']."'> </td></tr>";
		echo "<tr><th>Publisher: </th><td><center><input type = 'text' name = 'u_publisher' value = '" .$row['publisher']."'> </td></tr>";
		echo "<tr><th>Publish Year: </th><td><center><input type = 'text' name = 'u_pages' value = '" .$row['pages']."'> </td></tr>";
		echo "<tr><th>Detail: </th><td><center><textarea rows='50' cols='500'  name = 'u_detail' >" .$row['detail']. "</textarea></td></tr>";

		$statusValue = $row['status'];

		if($statusValue == 'Available')
		{
			echo "<tr><th>Status: </th><td><input type = 'radio' name = 'u_status' value = 'Available' checked>Available";
			echo "<input type = 'radio' name = 'u_status' value = 'Not Available'>Not Available</td>";
		}
		else
		{
			echo "<tr><th>Status: </th><td><input type = 'radio' name = 'u_status' value = 'Not Available' checked>Not Available";
			echo "<input type = 'radio' name = 'u_status' value = 'Available'> Available</td>";
	
		}
		echo "<tr><td colspan ='2'><input type ='submit' name = 'submit' value ='UPDATE'>
								<input type ='reset' name = 'reset' value ='CLEAR'></td></tr>";

		echo "</tr>";
	}
	echo "</table></div>";
}

else
{
	echo "0 result";
}

$conn->close();

include('footer.php');
?>

</body>