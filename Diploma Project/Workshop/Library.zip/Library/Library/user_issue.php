<!DOCTYPE html>
<html>
<head>
<title>ISSUE HISTORY</title>
<link rel="stylesheet" type="text/css" href="library.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>


<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
  background-color: white;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

</style>
</head>


<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;background-attachment: fixed">

<?php
    include("user_head.php");
    include('inc/connect.php'); 
?>



<table>

<input id="myInput" type="text" placeholder="Search.." size = "5">
<br><br>

  <thead>
  <tr>
          <th>Borrow ID</th>
           <th>Book ID</th>
          <th>ISBN</th>
          <th>Category</th>
          <th>Title</th>
          <th>Author</th>
          <th>Publisher</th>
          <th>Issue Date</th>
          <th>Return Date</th>
          <th>Action</th>

  </tr>
  </thead>

  <tbody id="myTable">

<?php 
session_start();

include('inc/connect.php');

$username = $_SESSION['username'];
$password = $_SESSION['password'];


$sql = "SELECT borrow.borrowid,borrow.bookid, book.isbn, book.category, book.title, book.author, book.publisher,borrow.dateborrow,borrow.datereturn FROM borrow INNER JOIN book ON borrow.bookid=book.bookid WHERE borrow.username = '$username'";

$result = $conn->query($sql);

if ($result->num_rows > 0) 
{
  //output data of each row
  while($row = $result->fetch_assoc())  
  { ?>

  <tr class="<?php if(isset($username)) echo $username;?>">
  <td><?php echo $row["borrowid"]; ?></td>
   <td><?php echo $row["bookid"]; ?></td>
  <td><?php echo $row["isbn"]; ?></td>
  <td><?php echo $row["category"]; ?></td>
  <td><?php echo $row["title"]; ?></td>
  <td><?php echo $row["author"]; ?></td>
  <td><?php echo $row["publisher"]; ?></td>
  <td><?php echo $row["dateborrow"]; ?></td>
  <td><?php if($row["datereturn"] ===  "NOT YET RETURN")
                                            {?>
                                            <span style="color:red">
                                             <?php   echo $row["datereturn"]; ?>
                                                </span>
                                            <?php }
                                              else if($row["datereturn"]=="LATE")
                                                {?>
                                            <span style="color:red">
                                             <?php   echo $row["datereturn"]; ?>
                                                </span>
                                            <?php }
                                            
                                            else {
                                             echo $row["datereturn"];
                                        }
                                            ?></td>

                                            
  <td><?php echo '<a href="returnBook.php?id='.$row['borrowid'].'">Return</a>' ?></td></tr>";
  </tr>
  
  <?php 
  }
  echo "</tr></tbody></table>";
  $conn->close();

include('footer.php');

}

else
{
  echo "<td colspan = 11><center>No data available in table</center></td>";
  echo "</tr></tbody></table>";
  $conn->close();

include('footer.php');
}


?>
</body>
</html>
