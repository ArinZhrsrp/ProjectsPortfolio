<html>
<head>
<title>PAYMENT PAGE</title>
<link rel="stylesheet" type="text/css" href="library.css">
</head>

<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;background-attachment: fixed">

<?php
    include("user_head.php");
?>

<br/>
<div class="container">

      <form action="member_userpayment.php" method="POST">
      <div class="container">
        <h1>PAYMENT</h1>
        <p>Please fill in this form to make a payment.</p>
        <hr>

        <label for="name"><b>Username</b></label>
        <input type="text" placeholder="Enter Username" name="name" required>

        <p><label for="type"><b>Payment Type &nbsp</b></label>
        <input type="radio" name="type" value="Late" checked>Late &nbsp
        <input type="radio" name="type" value="Lost" >Lost &nbsp
        <input type="radio" name="type" value="Broken" >Broken &nbsp
        <input type="radio" name="type" value="Other" >Other &nbsp</p>

        <p><label for="method"><b>Payment Method &nbsp</b></label>
        <input type="radio" name="method" value="Cash" checked>Cash &nbsp
        <input type="radio" name="method" value="Online Banking">Online Banking &nbsp</p>

        <p><label for="datepay"><b>Date :</b></label>
        <input type="date" name="datepay" required></p>

        <label for="fee"><b>Fee (RM): </b></label>
        <input type="text" placeholder="Enter Fee(RM)" name="fee" required>

         <p><label for="image"><b>Product Image</b></label></p>
        <p><input type="file" name="image" required></p>

		<p><label for="status"><b>Status : &nbsp</b></label>
        <input type="radio" name="status" value="Pending" checked>Pending &nbsp</p>

        <hr>

        <button type="submit" class="registerbtn">CONFIRM PAYMENT</button>
      </div>

</div>


<?php
    include("footer.php");
?>
       

</body>