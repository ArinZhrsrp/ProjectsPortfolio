<html>
<head>
<title>UPDATE USER</title>
<link rel="stylesheet" type="text/css" href="library.css">
</head>

<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;background-attachment: fixed">

<br/>
<!-- <div id = "content">
      <p><h1><marquee width =60% behavior = "alternate"><font face="monotype corsiva" color="black">SELAMAT DATANG</font></h1></marquee></p>
</div> -->

<?php 
session_start();

include("user_head.php");
include('inc/connect.php');

$username = $_SESSION['username'];
$password = $_SESSION['password'];

$sql = "SELECT * FROM user WHERE username = '$username' AND password = '$password'";

$result = $conn->query($sql);

if ($result->num_rows > 0) 
{
	//output data of each row
	while($row = $result->fetch_assoc())
	{
		echo "<center><h1>YOUR PROFILE</h1></center>";
		echo "<table align = 'center' border = '1' width = '80%'>";
		echo "<form action = 'updateFinal.php' method = 'post'>";
		echo "<tr><th>Id: </th><td>" . $row['userid'] . "</td></tr>";
		echo "<tr><th>Username: </th><td>" . $row['username'] . "</td></tr>";
		$courseValue = $row['course'];

	   	 if($courseValue == 'FTMK')
	    {
	      echo "<tr><th>Course: </th><td><input type = 'radio' name = 'u_course' value = 'FTMK' checked>FTMK";
	      echo "<input type = 'radio' name = 'u_course' value = 'FKE'>FKE";
	      echo "<input type = 'radio' name = 'u_course' value = 'FKEKK'>FKEKK";
	      echo "<input type = 'radio' name = 'u_course' value = 'FKM'>FKM";
	      echo "<input type = 'radio' name = 'u_course' value = 'FKP'>FKP";
	        echo "<input type = 'radio' name = 'u_course' value = 'FPTT'>FPTT";
	      echo "<input type = 'radio' name = 'u_course' value = 'FTKMP'>FTKMP";
	      echo "<input type = 'radio' name = 'u_course' value = 'FTKEE'>FTKEE</td>";

	    }
	    else if($courseValue == 'FKE')
	    {
	      echo "<tr><th>Course: </th><td><input type = 'radio' name = 'u_course' value = 'FKE' checked>FKE";
	      echo "<input type = 'radio' name = 'u_course' value = 'FTMK' >FTMK";
	      echo "<input type = 'radio' name = 'u_course' value = 'FKEKK'>FKEKK";
	      echo "<input type = 'radio' name = 'u_course' value = 'FKM'>FKM";
	      echo "<input type = 'radio' name = 'u_course' value = 'FKP'>FKP";
	        echo "<input type = 'radio' name = 'u_course' value = 'FPTT'>FPTT";
	      echo "<input type = 'radio' name = 'u_course' value = 'FTKMP'>FTKMP";
	      echo "<input type = 'radio' name = 'u_course' value = 'FTKEE'>FTKEE</td>";
	    }
	    else if($courseValue == 'FKEKK')
	    {
	      echo "<tr><th>Course: </th><td><input type = 'radio' name = 'u_course' value = 'FKEKK' checked>FKEKK";
	      echo "<input type = 'radio' name = 'u_course' value = 'FTMK' >FTMK";
	      echo "<input type = 'radio' name = 'u_course' value = 'FKE' >FKE";
	      echo "<input type = 'radio' name = 'u_course' value = 'FKM'>FKM";
	      echo "<input type = 'radio' name = 'u_course' value = 'FKP'>FKP";
	        echo "<input type = 'radio' name = 'u_course' value = 'FPTT'>FPTT";
	      echo "<input type = 'radio' name = 'u_course' value = 'FTKMP'>FTKMP";
	      echo "<input type = 'radio' name = 'u_course' value = 'FTKEE'>FTKEE</td>";
	    }
	    else if($courseValue == 'FKM')
	    {
	      echo "<tr><th>Course: </th><td><input type = 'radio' name = 'u_course' value = 'FKM' checked>FKM";
	      echo "<input type = 'radio' name = 'u_course' value = 'FTMK' >FTMK";
	      echo "<input type = 'radio' name = 'u_course' value = 'FKE' >FKE";
	      echo "<input type = 'radio' name = 'u_course' value = 'FKEKK'>FKEKK";
	      echo "<input type = 'radio' name = 'u_course' value = 'FKP'>FKP";
	        echo "<input type = 'radio' name = 'u_course' value = 'FPTT'>FPTT";
	      echo "<input type = 'radio' name = 'u_course' value = 'FTKMP'>FTKMP";
	      echo "<input type = 'radio' name = 'u_course' value = 'FTKEE'>FTKEE</td>";
	    }
	    else if($courseValue == 'FKP')
	    {
	      echo "<tr><th>Course: </th><td><input type = 'radio' name = 'u_course' value = 'FKP' checked>FKP";
	      echo "<input type = 'radio' name = 'u_course' value = 'FTMK' >FTMK";
	      echo "<input type = 'radio' name = 'u_course' value = 'FKE' >FKE";
	      echo "<input type = 'radio' name = 'u_course' value = 'FKEKK'>FKEKK";
	      echo "<input type = 'radio' name = 'u_course' value = 'FKM'>FKM";
	        echo "<input type = 'radio' name = 'u_course' value = 'FPTT'>FPTT";
	      echo "<input type = 'radio' name = 'u_course' value = 'FTKMP'>FTKMP";
	      echo "<input type = 'radio' name = 'u_course' value = 'FTKEE'>FTKEE</td>";
	    }
	    else if($courseValue == 'FPTT')
	    {
	     echo "<tr><th>Course: </th><td><input type = 'radio' name = 'u_course' value = 'FPTT' checked>FPTT";
	      echo "<input type = 'radio' name = 'u_course' value = 'FTMK' >FTMK";
	      echo "<input type = 'radio' name = 'u_course' value = 'FKE' >FKE";
	      echo "<input type = 'radio' name = 'u_course' value = 'FKEKK'>FKEKK";
	      echo "<input type = 'radio' name = 'u_course' value = 'FKM'>FKM";
	        echo "<input type = 'radio' name = 'u_course' value = 'FKP'>FKP";
	      echo "<input type = 'radio' name = 'u_course' value = 'FTKMP'>FTKMP";
	      echo "<input type = 'radio' name = 'u_course' value = 'FTKEE'>FTKEE</td>";
	    }
	    else if($courseValue == 'FTKMP')
	    {
	     echo "<tr><th>Course: </th><td><input type = 'radio' name = 'u_course' value = 'FTKMP' checked>FTKMP";
	      echo "<input type = 'radio' name = 'u_course' value = 'FTMK' >FTMK";
	      echo "<input type = 'radio' name = 'u_course' value = 'FKE' >FKE";
	      echo "<input type = 'radio' name = 'u_course' value = 'FKEKK'>FKEKK";
	      echo "<input type = 'radio' name = 'u_course' value = 'FKM'>FKM";
	        echo "<input type = 'radio' name = 'u_course' value = 'FKP'>FKP";
	      echo "<input type = 'radio' name = 'u_course' value = 'FPTT'>FPTT";
	      echo "<input type = 'radio' name = 'u_course' value = 'FTKEE'>FTKEE</td>";
	    }
	    else 
	    {
	     echo "<tr><th>Course: </th><td><input type = 'radio' name = 'u_course' value = 'FTKEE' checked>FTKEE";
	      echo "<input type = 'radio' name = 'u_course' value = 'FTMK' >FTMK";
	      echo "<input type = 'radio' name = 'u_course' value = 'FKE' >FKE";
	      echo "<input type = 'radio' name = 'u_course' value = 'FKEKK'>FKEKK";
	      echo "<input type = 'radio' name = 'u_course' value = 'FKM'>FKM";
	        echo "<input type = 'radio' name = 'u_course' value = 'FKP'>FKP";
	      echo "<input type = 'radio' name = 'u_course' value = 'FPTT'>FPTT";
	      echo "<input type = 'radio' name = 'u_course' value = 'FTKMP'>FTKMP</td>";
	    }


		$genderValue = $row['gender'];

		if($genderValue == 'Male')
		{
			echo "<tr><th>Gender: </th><td><input type = 'radio' name = 'u_gender' value = 'Male' checked>Male";
			echo "<input type = 'radio' name = 'u_gender' value = 'Female'>Female</td>";
		}
		else
		{
			echo "<tr><th>Gender: </th><td><input type = 'radio' name = 'u_gender' value = 'Female' checked>Female";
			echo "<input type = 'radio' name = 'u_gender' value = 'Male'>Male</td>";
		}

		echo "<tr><th>DOB: </th><td><input type = 'text' name = 'u_dob' required value = '" .$row['dob']."'> </td></tr>";
		echo "<tr><th>Email: </th><td><input type = 'text' name = 'u_email' required value = '" .$row['email']."'> </td></tr>";
		echo "<tr><th>Password: </th><td>" . $row['password'] . "</td></tr>";

	
		echo "<tr><td colspan ='2'><input type ='submit' name = 'submit' value ='UPDATE'>
									<input type ='reset' name = 'reset' value ='CLEAR'></td></tr>";

		echo "</tr>";
	}
	echo "</table>";
}

else
{
	echo "0 result";
}

$conn->close();

include('footer.php');
?>

</body>