<html>
<head>
<title>INSERT BOOK</title>
</head>

<body>

<?php
session_start();

include("admin_head.php");
$con = mysqli_connect("localhost","root","","library");

// Escape special characters, if any
$isbn = mysqli_real_escape_string($con, $_POST['isbn']);
$category = mysqli_real_escape_string($con, $_POST['category']);
$title = mysqli_real_escape_string($con, $_POST['title']);
$author = mysqli_real_escape_string($con, $_POST['author']);
$publisher = mysqli_real_escape_string($con, $_POST['publisher']);
$pages = mysqli_real_escape_string($con, $_POST['pages']);
$detail = mysqli_real_escape_string($con, $_POST['detail']);
$status = mysqli_real_escape_string($con, $_POST['status']);

if($con->connect_error){
die ('Failed to connect to MySQL: ' . $mysqli->connect_errno);
}
if($_SERVER['REQUEST_METHOD'] == "POST"){
if(!empty($_FILES['fileToUpload']['tmp_name'])){
$img = ($_FILES['fileToUpload']['tmp_name']);
$check = getimagesize($img);
if($check == false) {
die($_FILES['fileToUpload']['name'] . " is not a valid image file.");
}
}
$img= $_FILES['fileToUpload']['name'];
$temppath= $_FILES['fileToUpload']['tmp_name'];
move_uploaded_file($temppath,"source/$img");
$stmt = $con->prepare("INSERT INTO book VALUES (NULL,'$img', '$isbn', '$category', '$title', '$author', '$publisher', '$pages', '$detail', '$status')"); 


if($stmt->execute()){
echo "<center>$title Has Been Added!\n";
echo "<meta http-equiv=\"refresh\"content=\"3;URL=admin_book.php\">";
}
else{
echo "Try Again";
}
}

mysqli_close($con);
?>