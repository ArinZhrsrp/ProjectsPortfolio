<html>
<head>
<title>OBJECTIVE</title>
<link rel="stylesheet" type="text/css" href="library.css">
</head>

<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;background-attachment: fixed">

<?php
 
    include("head.php");
?>

<div class="container">
      <center><p><h1>OBJECTIVE</h1></p></center>
      
      <p>1. To cater the information needs of the University by providing resources which fulfill the teaching, learning, research and consultancy requirements.</p>

      <p>2. To deliver and promote information services to the clients.</p>

      <p>3. To enhance the efficiency of knowledge and information sharing with the clients.</p>

      <p>4. To inculcate the culture of knowledge in UTeM, as well as its neighbourhood in order to reflect a knowledgeable community.</p>

      <p>5. To develop creative and innovative professionals with integrity in tandem with the mission of UTeM.


</div>

<?php
    include("footer.php");
?>
       

</body>