<html>
<head>
<title>LIBRARY MANAGEMENT SYSTEM</title>
<link rel="stylesheet" type="text/css" href="library.css">
</head>

<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;background-attachment: fixed">

<center>
  <div id = "header">
      <center><a><img src = "source/library.png" width="100px" height="150px"></a></center>
    </div>

<ul>
    <li class="dropdown">
      <a href="home.php" class="dropbtn">HOME</a>
    </li>

    <li class="dropdown">
      <a href="book.php" class="dropbtn">BOOK</a>
    </li>

    <li class="dropdown">
      <a href="#about" class="dropbtn">ABOUT US</a>
      <div  class = "dropdown-content">
          <a href="background.php">BACKGROUND</a>
          <a href="objective.php">OBJECTIVE</a>
      </div>
    </li>

    <li class="dropdown">
      <a href="contact.php" class="dropbtn">CONTACT US</a>
    </li>
   

 <li style="float:right"><a class="active" onclick="document.getElementById('id01').style.display='block'">LOGIN</a></li>
</ul></center>

<!-- Admin Login-->  
<div id="id01" class="modal"> 
  <form class="modal-content animate" action="login.php" method="post">
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="source/avatar.png" alt="Avatar" class="avatar">
    </div>

    <div class="container">
      <label for="username"><b>Username</b></label>
      <input type="text" placeholder="Enter Username" name="username" required>

      <label for="password"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="password" required>
        
      <button type="submit">Login</button>

      <label>
      <center><input type="checkbox" checked="checked" name="remember">Remember me</center>
      </label>
    </div>
    <div class="container" style="background-color:#f1f1f1">
      <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
      <span class="psw">Forgot <a href="#">password?</a></span>
    </div>

     <center><p class="center"><b>New User/ <a href="register.php"> Sign-up now.. </a></b></p></center>
  </form>
</div>

<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

</script> 


<br/>
</body>