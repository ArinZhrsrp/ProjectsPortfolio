<html>
<head>
<title>UPDATE USER</title>
</head>

<body>

<?php
session_start();

include("admin_head.php");
include('inc/connect.php');

$username = $_SESSION['username'];
$course = $_POST['u_course'];
$gdr = $_POST['u_gender'];
$dob = $_POST['u_dob'];
$email = $_POST['u_email'];
$password = $_SESSION['password'];

$sql = "UPDATE user SET course='".$course."', gender='".$gdr."',dob='".$dob."',email='".$email."' where username = '$username' and password = '$password'";

$result = $conn->query($sql);


if($conn->query($sql) === TRUE) {
	echo"<p style = 'text-align:center'>Data $username Had Been Updated!";
	echo "</p>";
} else {
	echo "<p>";
	echo"<p style = 'text-align:center'>ERROR: " .$sql. "<br>" . $conn->error;
	echo "</p>";
}
 //closes specified connection
$conn->close();
include('footer.php');
?>