<html>
<head>
<title>RETURN BOOK</title>
<link rel="stylesheet" type="text/css" href="library.css">
</head>

<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;background-attachment: fixed">

<br/>
<!-- <div id = "content">
      <p><h1><marquee width =60% behavior = "alternate"><font face="monotype corsiva" color="black">SELAMAT DATANG</font></h1></marquee></p>
</div> -->

<?php 
session_start();

include("user_head.php");
include('inc/connect.php');

$id = $_REQUEST['id'];
$username = $_SESSION['username'];
$password = $_SESSION['password'];

$sql = "SELECT borrow.borrowid,borrow.bookid, book.isbn, book.category, book.title, book.author, book.publisher,borrow.dateborrow,borrow.datereturn FROM borrow INNER JOIN book ON borrow.bookid=book.bookid WHERE borrow.borrowid = '$id'";

$result = $conn->query($sql);

if ($result->num_rows > 0) 
{
	//output data of each row
	while($row = $result->fetch_assoc())
	{
		echo "<div class='container'>";
		echo "<center><h1>CONFIRM ISSUE</h1></center>";
		echo "<table align = 'center' border = '1' width = '50%' color='white'>";
		echo "<form action = 'member_return.php' method = 'post'>";
		echo "<tr><th>Borrow ID: </th><td><input type='text' name='u_id' readonly value='".$row['borrowid']."' required></td></tr>";
		echo "<tr><th>Book ID: </th><td><input type='text' name='u_bookid' readonly value='".$row['bookid']."' required></td></tr>";
		echo "<tr><th>ISBN: </th><td><input type='text' name='u_isbn' readonly value='".$row['isbn']."' required></td></tr>";
		echo "<tr><th>Category: </th><td><input type='text' name='u_category' readonly value='".$row['category']."' required></td></tr>";
		echo "<tr><th>Title: </th><td><center><input type = 'text' name = 'u_title' readonly value = '" .$row['title']."'> </td></tr>";
		echo "<tr><th>Author: </th><td><center><input type = 'text' name = 'u_author' readonly value = '" .$row['author']."'> </td></tr>";
		echo "<tr><th>Publisher: </th><td><center><input type = 'text' name = 'u_publisher' readonly value = '" .$row['publisher']."'> </td></tr>";
		echo "<tr><th>Date Borrow: </th><td><center><input type = 'text' name = 'u_dateborrow' readonly value = '" .$row['dateborrow']."'> </td></tr>";
		echo "<tr><th width='40' height='50'>Date Return: </th><td><center><input type = 'date' name = 'u_return' value = '" .$row['datereturn']."' width='400' height='200'> &nbsp <<< Please Select Date Return </td></tr>";
		echo "<tr><td colspan ='2'><input type ='submit'  class='registerbtn' name = 'submit' value ='RETURN'></td></tr>";

		echo "</tr>";
	}
	echo "</table><?/div>";
}

else
{
	echo "0 result";
}

$conn->close();

include('footer.php');
?>

</body>