<html>
<head>
<title>PAYMENT REPORT</title>
<link rel="stylesheet" type="text/css" href="library.css">
</head>

<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  background-attachment: fixed">

<?php
    include("admin_head.php");
?>

<br/>
<div class="container">
  <center>
    <h1>PAYMENT &nbsp; REPORT </h1>
    <form id="report" method="post" action="paymentReport.php">
    <table cellpadding="6" cellspacing="0" border="" width="50%">
    <tr><td width="40%">From :</td><td><input type="date" name="fromdate"></input></td></tr>
    <tr><td width="40%">To :</td><td><input type="date" name="todate"></input></td></tr>
    <tr><td colspan="2" align="center"><button type="submit" name = "submit" value="Submit" >View</button></td></tr>
    </table>



</form>
</center>
</div>

<?php
    include("footer.php");
?>
       

</body>