<!DOCTYPE html>
<html>
<head>
<title>BOOK</title>
<link rel="stylesheet" type="text/css" href="library.css">

<link href='//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css' rel='stylesheet' type='text/css'>

<!-- jQuery Library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Datatable JS -->
<script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

</head>


<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  background-attachment: fixed">

<?php
    include("user_head.php");
?>

<!-- HTML -->
<div class="container">
      <center><p><h1>BOOK LIST</h1></p>
   <!-- Custom Filter -->
   <table>
     <tr>
       <td>
         <select id='searchByCategory'>
           <option value=''>-- Select Category--</option>
           <option value='Action'>Action</option>
           <option value='Adventure'>Adventure</option>
            <option value='Art'>Art</option>
           <option value='Autobigraphy'>Autobigraphy</option>
            <option value='Dictionary'>Dictionary</option>
           <option value='Drama'>Drama</option>
            <option value='Encyclopedia'>Encyclopedia</option>
           <option value='Fantasy'>Fantasy</option>
            <option value='Guide'>Guide</option>
           <option value='Journal'>Journal</option>
            <option value='History'>History</option>
            <option value='Horror'>Horror</option>
           <option value='Religion'>Religion</option>
            <option value='Review'>Review</option>
           <option value='Romance'>Romance</option>
             <option value='Science Fiction'>Science Fiction</option>
           <option value='Suspense'>Suspense</option>
            <option value='Textbook'>Textbook</option>
           <option value='Thriller'>Thriller</option>
            <option value='Travel'>Travel</option>
           <option value='True Crime'>True Crime</option>
         </select>
       </td>
       <td>
         <select id='searchByStatus'>
           <option value=''>-- Select Status--</option>
           <option value=''>All</option>
           <option value='Available'>Available</option>
           <option value='Not Available'>Not Available</option>
          </select>
       </td>
     </tr>
   </table>

   <!-- Table -->
   <table id='empTable' class='display dataTable'>
     <thead>
       <tr>
        <th>Book ID</th>
          <th>ISBN</th>
          <th>Category</th>
          <th>Title</th>
          <th>Author</th>
          <th>Publisher</th>
          <th>Pages</th>
          <th>Detail</th>
          <th>Status</th>
          <th>Action</th>

       </tr>
     </thead>

   </table>


   <script>
     $(document).ready(function(){
  var dataTable = $('#empTable').DataTable({
    'processing': true,
    'serverSide': true,
    'serverMethod': 'post',
    //'searching': false, // Remove default Search Control
    'ajax': {
       'url':'ajaxfile6.php',
       'data': function(data){
          // Read values
          var category = $('#searchByCategory').val();
          var status = $('#searchByStatus').val();

          // Append to data
          data.searchByCategory = category;
          data.searchByStatus = status;

       }
    },
    'columns': [
  { data: 'bookid' },
       { data: 'isbn' },
       { data: 'category' },
       { data: 'title' },
       { data: 'author' },
       { data: 'publisher' }, 
       { data: 'pages' },
       { data: 'detail' },
       { data: 'status' },
       { data: 'action' },

    ]
  });

  $('#searchByCategory').change(function(){
    dataTable.draw();
  });
 $('#searchByStatus').change(function(){
    dataTable.draw();
  });  
});
   </script>

</div>

<?php
    include("footer.php");
?>


</body>
</html>
