<html>
<head>
<title>RETURN BOOK</title>
<link rel="stylesheet" type="text/css" href="library.css">
</head>

<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;background-attachment: fixed">

<br/>
<!-- <div id = "content">
      <p><h1><marquee width =60% behavior = "alternate"><font face="monotype corsiva" color="black">SELAMAT DATANG</font></h1></marquee></p>
</div> -->

<?php 
session_start();

include("admin_head.php");
include('inc/connect.php');

$id = $_REQUEST['id'];
$username = $_SESSION['username'];
$password = $_SESSION['password'];

$sql = "SELECT * FROM borrow where borrowid = $id";

$result = $conn->query($sql);

if ($result->num_rows > 0) 
{
	//output data of each row
	while($row = $result->fetch_assoc())
	{
		echo "<center><h1>RETURN BOOK</h1></center>";
		echo "<table align = 'center' border = '1' width = '50%' color='white'>";
		echo "<form action = 'updateFinalBorrow.php' method = 'post'>";
		echo "<tr><th>Borrow Id: </th><td><input type='text' name='u_id' value='".$row['borrowid']."' required></td></tr>";
		echo "<tr><th>Book Id: </th><td><input type='text' name='u_bookid' value='".$row['bookid']."' required></td></tr>";
		echo "<tr><th>Username: </th><td><input type='text' name='u_name' readonly value='".$row['username']."' required></td></tr>";
		echo "<tr><th>Date Borrow: </th><td><input type='text' name='u_dateborrow'  value='".$row['dateborrow']."' required></td></tr>";
		echo "<tr><th>Date Return: </th><td><center><input type = 'date' name = 'u_return' value = '" .$row['datereturn']."'> &nbsp <<< Please Select Date Return </td></tr>";
	
		echo "<tr><td colspan ='2'><input type ='submit' name = 'submit' value ='RETURN'>
								<input type ='reset' name = 'reset' value ='CLEAR'></td></tr>";

		echo "</tr>";
	}
	echo "</table>";
}

else
{
	echo "0 result";
}

$conn->close();

include('footer.php');
?>

</body>