<html>
<head>
<title>BORROW BOOK</title>
</head>

<body>

<?php
session_start();

include("user_head.php");
include('inc/connect.php');

$id = $_POST['u_id'];
$return = $_POST['u_return'];
$username = $_SESSION['username'];


$sql = "INSERT INTO borrow (bookid,username,datereturn) VALUES ('$id','$username','$return')" or die ("Error inserting data info table");

if($conn->query($sql) === TRUE) {
	//echo"<p style = 'text-align:center'>Please Wait...";
	//echo "<meta http-equiv=\"refresh\"content=\"3;URL=member_update.php\">";
	echo "</p>";
} else {
	echo "<p>";
	echo"<p style = 'text-align:center'>ERROR: " .$sql. "<br>" . $conn->error;
	echo "</p>";
}

$sql2 = "UPDATE book SET status='Not Available' WHERE bookid ='$id'";

if($conn->query($sql2) === TRUE) {
	echo"<p style = 'text-align:center'>You have successfully borrow a book.";
	echo "<meta http-equiv=\"refresh\"content=\"3;URL=user_book.php\">";
	echo "</p>";
} else {
	echo "<p>";
	echo"<p style = 'text-align:center'>ERROR: " .$sql2. "<br>" . $conn->error;
	echo "</p>";
}
 //closes specified connection
$conn->close();
include('footer.php');
?>