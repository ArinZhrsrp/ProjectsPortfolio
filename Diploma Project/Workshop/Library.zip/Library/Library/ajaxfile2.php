<?php
include 'config.php';

## Read value
$draw = $_POST['draw'];
$row = $_POST['start'];
$rowperpage = $_POST['length']; // Rows display per page
$columnIndex = $_POST['order'][0]['column']; // Column index
$columnName = $_POST['columns'][$columnIndex]['data']; // Column name
$columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
$searchValue = $_POST['search']['value']; // Search value

## Custom Field value
$searchByType = $_POST['searchByType'];
$searchByMethod = $_POST['searchByMethod'];

## Search 
$searchQuery = " ";
if($searchByType != ''){
   $searchQuery .= " and (type='".$searchByType."') ";
}
if($searchByMethod != ''){
   $searchQuery .= " and (method='".$searchByMethod."') ";
}
if($searchValue != ''){
   $searchQuery .= " and (paymentid like '%".$searchValue."%' or name like '%".$searchValue."%' or type like '%".$searchValue."%' or method like '%".$searchValue."%' or fee like'%".$searchValue."%' or status like'%".$searchValue."%'  ) ";
}

## Total number of records without filtering
$sel = mysqli_query($con,"select count(*) as allcount from payment");
$records = mysqli_fetch_assoc($sel);
$totalRecords = $records['allcount'];

## Total number of records with filtering
$sel = mysqli_query($con,"select count(*) as allcount from payment WHERE 1 ".$searchQuery);
$records = mysqli_fetch_assoc($sel);
$totalRecordwithFilter = $records['allcount'];

## Fetch records
$empQuery = "select * from payment WHERE 1 ".$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$row.",".$rowperpage;
$empRecords = mysqli_query($con, $empQuery);
$data = array();

while ($row = mysqli_fetch_assoc($empRecords)) {
   $data[] = array(
     "paymentid"=>$row['paymentid'],
     "name"=>$row['name'],
     "type"=>$row['type'],
     "method"=>$row['method'],
     "datepay"=>$row['datepay'],
     "fee"=>$row['fee'],
     "status"=>$row['status'],
     "action"=>'<a href="delete_Payment.php?id='.$row['paymentid'].'">Delete</a>',
     "action2"=>'<a href="updatePayment.php?id='.$row['paymentid'].'">Update</a>'

   );
}

## Response
$response = array(
  "draw" => intval($draw),
  "iTotalRecords" => $totalRecords,
  "iTotalDisplayRecords" => $totalRecordwithFilter,
  "aaData" => $data
);

echo json_encode($response);