<!DOCTYPE html>
<html>
<head>
<title>PAYMENT HISTORY</title>
<link rel="stylesheet" type="text/css" href="library.css">

<link href='//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css' rel='stylesheet' type='text/css'>

<!-- jQuery Library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Datatable JS -->
<script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

</head>


<body style = "background-image: url('source/bgimage.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  background-attachment: fixed">

<?php
    include("admin_head.php");
?>

<!-- HTML -->
<div class="container">
    <center><p><h1>TOTAL MONTHLY PAYMENT</h1></p>
   <!-- Custom Filter -->
   <table>
     <tr>
       <td>
         <select id='searchByMonth'>
           <option value=''>-- Select Month --</option>
           <option value='JANUARI'>JANUARI</option>
            <option value='FEBRUARI'>FEBRUARI</option>
           <option value='MARCH'>MARCH</option>
            <option value='APRIL'>APRIL</option>
             <option value='MAY'>MAY</option>
            <option value='JUN'>JUN</option>
           <option value='JULY'>JULY</option>
            <option value='AUGUST'>AUGUST</option>
             <option value='SEPTEMBER'>SEPTEMBER</option>
            <option value='OCTOBER'>OCTOBER</option>
           <option value='NOVEMBER'>NOVEMBER</option>
            <option value='DECEMBER'>DECEMBER</option>
         </select>
       </td>
     </tr>
   </table>

   <!-- Table -->
   <table id='empTable' class='display dataTable'>
     <thead>
       <tr>
         <th>Payment ID</th>
          <th>Username</th>
          <th>Payment Type</th>
          <th>Payment Method</th>
          <th>Date</th>
          <th>Fee</th>
          <th>Action</th>
       </tr>
     </thead>

   </table>


   <script>
     $(document).ready(function(){
  var dataTable = $('#empTable').DataTable({
    'processing': true,
    'serverSide': true,
    'serverMethod': 'post',
    //'searching': false, // Remove default Search Control
    'ajax': {
       'url':'ajaxfile2.php',
       'data': function(data){
          // Read values
          var type = $('#searchByType').val();
          var method = $('#searchByMethod').val();

          // Append to data
          data.searchByType = type;
          data.searchByMethod = method;

       }
    },
    'columns': [
       { data: 'paymentid' }, 
       { data: 'username' },
       { data: 'type' },
       { data: 'method' },
       { data: 'datepay' },
       { data: 'fee' }, 
       { data: 'action' },
    ]
  });

  $('#searchByType').change(function(){
    dataTable.draw();
  });
  $('#searchByMethod').change(function(){
    dataTable.draw();
  });
});
   </script>

</div>

<?php
    include("footer.php");
?>


</body>
</html>
